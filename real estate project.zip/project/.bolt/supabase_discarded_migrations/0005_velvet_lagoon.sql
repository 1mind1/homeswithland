/*
  # Seed Blog Posts

  1. Changes
    - Add initial blog posts with admin author
*/

-- Insert initial blog posts
INSERT INTO blog_posts (title, content, slug, category, published, author_id)
VALUES
  (
    'Finding Your Perfect Rural Property',
    'A comprehensive guide to finding and evaluating rural properties. Consider factors like water rights, soil quality, and zoning regulations...',
    'finding-perfect-rural-property',
    'Buying Guide',
    true,
    (SELECT id FROM profiles WHERE role = 'admin' LIMIT 1)
  ),
  (
    'Starting a Homestead on a Budget',
    'Practical tips for beginning your homesteading journey without breaking the bank. Learn about essential investments and cost-saving strategies...',
    'starting-homestead-on-budget',
    'Homesteading',
    true,
    (SELECT id FROM profiles WHERE role = 'admin' LIMIT 1)
  ),
  (
    'Understanding Land Surveys',
    'Everything you need to know about land surveys when buying property. Types of surveys, what they reveal, and when you need them...',
    'understanding-land-surveys',
    'Education',
    true,
    (SELECT id FROM profiles WHERE role = 'admin' LIMIT 1)
  );