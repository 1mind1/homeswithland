/*
  # Create blog schema and profiles

  1. Changes
    - Add updated_at trigger function
    - Create profiles table with RLS
    - Create blog_posts table with RLS
    - Add policies for blog post access control
    
  2. Security
    - Enable RLS on both tables
    - Add policies for blog post visibility and management
*/

-- Create updated_at function if it doesn't exist
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create profiles table if it doesn't exist
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  email text,
  full_name text,
  avatar_url text,
  role text DEFAULT 'user',
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on profiles if not already enabled
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_tables 
    WHERE schemaname = 'public' 
    AND tablename = 'profiles' 
    AND rowsecurity = true
  ) THEN
    ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Create blog_posts table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_tables 
    WHERE schemaname = 'public' 
    AND tablename = 'blog_posts'
  ) THEN
    CREATE TABLE blog_posts (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      title text NOT NULL,
      content text NOT NULL,
      slug text UNIQUE NOT NULL,
      author_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
      published boolean NOT NULL DEFAULT false,
      category text NOT NULL,
      created_at timestamptz DEFAULT now(),
      updated_at timestamptz DEFAULT now()
    );

    -- Enable RLS on blog_posts
    ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;

    -- Create policies for blog_posts
    CREATE POLICY "Anyone can view published blog posts"
      ON blog_posts
      FOR SELECT
      USING (published = true);

    CREATE POLICY "Authors can manage their own posts"
      ON blog_posts
      FOR ALL
      TO authenticated
      USING (author_id = auth.uid())
      WITH CHECK (author_id = auth.uid());

    CREATE POLICY "Admins can manage all posts"
      ON blog_posts
      FOR ALL
      TO authenticated
      USING (
        EXISTS (
          SELECT 1 FROM profiles
          WHERE profiles.id = auth.uid()
          AND profiles.role = 'admin'
        )
      )
      WITH CHECK (
        EXISTS (
          SELECT 1 FROM profiles
          WHERE profiles.id = auth.uid()
          AND profiles.role = 'admin'
        )
      );

    -- Add trigger for updated_at
    CREATE TRIGGER update_blog_posts_updated_at
      BEFORE UPDATE ON blog_posts
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;