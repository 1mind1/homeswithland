import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
});

const PRICE_IDS = {
  monthly: 'price_1Qb0hmCdkhGjWcEpv84Q0GsK',
  annual: 'price_1Qb0i9CdkhGjWcEp5J9oSX8t',
  lifetime: 'price_1Qb0iSCdkhGjWcEpFXaUncIP'
};

export default async function handler(req: Request) {
  if (req.method !== 'POST') {
    return new Response('Method not allowed', { status: 405 });
  }

  try {
    const { plan } = await req.json();
    const priceId = PRICE_IDS[plan as keyof typeof PRICE_IDS];
    
    if (!priceId) {
      throw new Error('Invalid plan selected');
    }

    const session = await stripe.checkout.sessions.create({
      mode: plan === 'lifetime' ? 'payment' : 'subscription',
      line_items: [{
        price: priceId,
        quantity: 1,
      }],
      success_url: `${req.headers.get('origin')}/signup/${plan}/account`,
      cancel_url: `${req.headers.get('origin')}/plans`,
    });

    return new Response(JSON.stringify({ sessionId: session.id }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  } catch (error) {
    console.error('Checkout session error:', error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : 'Failed to create checkout session'
      }), {
        status: 500,
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );
  }
}