import Stripe from 'stripe';
import { supabase } from '../src/lib/supabase';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
});

const relevantEvents = new Set([
  'payment_intent.succeeded',
  'payment_intent.payment_failed',
  'customer.subscription.created',
  'customer.subscription.updated',
  'customer.subscription.deleted',
]);

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return new Response('Method not allowed', { status: 405 });
  }
  
  console.log('Webhook request received:', {
    method: request.method,
    timestamp: new Date().toISOString()
  });

  const body = await request.text();
  const signature = request.headers.get('stripe-signature');

  if (!signature) {
    return new Response('No signature found', { status: 400 });
  }

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
    
    console.log('Webhook event verified:', {
      type: event.type,
      id: event.id,
      timestamp: new Date(event.created).toISOString()
    });

  } catch (err) {
    console.error('Webhook signature verification failed:', {
      error: err.message,
      timestamp: new Date().toISOString()
    });
    return new Response(
      JSON.stringify({ error: 'Invalid signature' }), 
      { 
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      }
    );
  }

  if (relevantEvents.has(event.type)) {
    try {
      switch (event.type) {
        case 'payment_intent.succeeded':
          await handlePaymentSuccess(event.data.object as Stripe.PaymentIntent);
          break;

        case 'payment_intent.payment_failed':
          await handlePaymentFailure(event.data.object as Stripe.PaymentIntent);
          break;

        default:
          console.warn('Unhandled relevant event!', event.type);
      }
    } catch (error) {
      console.error('Webhook handler failed:', error);
      return new Response('Webhook handler failed', { status: 500 });
    }
  }

  return new Response(JSON.stringify({ received: true }), {
    status: 200,
    headers: { 'Content-Type': 'application/json' },
  });
}

async function handlePaymentSuccess(paymentIntent: Stripe.PaymentIntent) {
  const { userId, plan } = paymentIntent.metadata;
  
  try {
    // Update user's subscription status
    await supabase.from('subscriptions').insert({
      user_id: userId,
      status: 'active',
      price_id: plan,
      metadata: { 
        paymentIntentId: paymentIntent.id,
        amount: paymentIntent.amount,
      },
    });

    // Update user's role to 'subscriber'
    await supabase
      .from('profiles')
      .update({ role: 'subscriber' })
      .eq('id', userId);

  } catch (error) {
    console.error('Error updating subscription status:', error);
    throw error;
  }
}

async function handlePaymentFailure(paymentIntent: Stripe.PaymentIntent) {
  const { userId } = paymentIntent.metadata;
  
  try {
    // Log failed payment attempt
    await supabase.from('payment_failures').insert({
      user_id: userId,
      payment_intent_id: paymentIntent.id,
      error: paymentIntent.last_payment_error?.message,
      amount: paymentIntent.amount,
    });
  } catch (error) {
    console.error('Error logging payment failure:', error);
    throw error;
  }
}