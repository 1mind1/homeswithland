import express from 'express'
import cors from 'cors'
import Stripe from 'stripe'
import dotenv from 'dotenv'

dotenv.config()

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('STRIPE_SECRET_KEY is required')
}

const app = express()
const port = process.env.PORT || 3000

// Configure CORS before other middleware
app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? 'https://homeswith.land'
    : ['http://localhost:5173', 'http://localhost:5174', 'http://localhost:4173'],
  methods: ['POST', 'GET'],
  credentials: true,
  allowedHeaders: ['Content-Type', 'Authorization']
}))

// Parse JSON bodies for all routes except webhooks
app.use((req, res, next) => {
  if (req.path === '/api/webhooks') {
    express.raw({ type: '*/*' })(req, res, next);
  } else {
    express.json()(req, res, next);
  }
});
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2023-10-16'
})

const PLAN_AMOUNTS = {
  monthly: 579,   // $5.79
  annual: 5900,   // $59.00
  lifetime: 12900 // $129.00
}
  origin: process.env.NODE_ENV === 'production' 
    ? 'https://homeswith.land'
    : ['http://localhost:5173', 'http://localhost:5174', 'http://localhost:4173'],

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' })
})

app.post('/api/create-payment-intent', async (req, res) => {
  try {
    const { plan } = req.body

    if (!plan) {
      return res.status(400).json({
        error: 'Missing plan parameter',
      });
    }
    
    if (typeof plan !== 'string') {
      return res.status(400).json({ 
        error: 'Invalid plan provided',
      });
    }
    
    const amount = PLAN_AMOUNTS[plan];
    if (!amount) {
      return res.status(400).json({ 
        error: 'Invalid plan selected',
        validPlans: Object.keys(PLAN_AMOUNTS)
      });
    }

    const paymentIntent = await stripe.paymentIntents.create({
      amount,
      currency: 'usd',
      automatic_payment_methods: {
        enabled: true,
      },
      metadata: {
        plan,
      },
    })

    return res.status(200).json({ 
      clientSecret: paymentIntent.client_secret 
    });
  } catch (error) {
    console.error('Payment intent error:', error);
    return res.status(500).json({ 
      error: 'Failed to create payment intent'
    });
  }
});

app.post('/api/webhooks', async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  console.log('Webhook request received:', {
    signature: !!sig,
    hasSecret: !!webhookSecret,
    timestamp: new Date().toISOString()
  });

  if (!sig || !webhookSecret) {
    return res.status(400).json({ error: 'Missing signature or webhook secret' });
  }

  try {
    const event = stripe.webhooks.constructEvent(
      req.rawBody || req.body,
      sig,
      webhookSecret
    );

    console.log('Webhook event verified:', {
      type: event.type,
      id: event.id,
      timestamp: new Date(event.created).toISOString()
    });

    // Handle specific event types
    switch (event.type) {
      case 'payment_intent.succeeded':
        const paymentIntent = event.data.object;
        console.log('Payment succeeded:', {
          id: paymentIntent.id,
          amount: paymentIntent.amount,
          status: paymentIntent.status,
          metadata: paymentIntent.metadata
        });
        break;
      case 'payment_intent.payment_failed':
        const failedPayment = event.data.object;
        console.log('Payment failed:', {
          id: failedPayment.id,
          amount: failedPayment.amount,
          error: failedPayment.last_payment_error,
          metadata: failedPayment.metadata
        });
        break;
      default:
        console.log('Unhandled event type:', {
          type: event.type,
          id: event.id
        });
    }

    res.json({ received: true });
  } catch (err) {
    console.error('Webhook error:', {
      message: err.message,
      timestamp: new Date().toISOString(),
      headers: req.headers
    });
    return res.status(400).json({ error: `Webhook Error: ${err.message}` });
  }
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`)
})