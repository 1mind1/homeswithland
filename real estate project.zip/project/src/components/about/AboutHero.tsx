export function AboutHero() {
  return (
    <div className="relative isolate overflow-hidden bg-gray-900 py-24 sm:py-32">
      <img
        src="https://images.unsplash.com/photo-1721149122657-7b5440f39160?q=80&w=2071&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
        alt="Country home at sunset"
        className="absolute inset-0 -z-10 h-full w-full object-cover brightness-50"
      />
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl lg:mx-0">
          <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl">
            Breaking Free from Cookie-Cutter Living
          </h1>
          <p className="mt-6 text-lg leading-8 text-gray-300">
            We're on a mission to help people discover affordable properties with land,
            enabling them to break free from low quality, overpriced homes and create the
            lifestyle they've always dreamed of.
          </p>
        </div>
      </div>
    </div>
  );
}