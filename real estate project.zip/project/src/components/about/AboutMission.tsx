import { Home, Heart, Users, PiggyBank, Sprout, Sun } from 'lucide-react';

const values = [
  {
    name: 'Affordability First',
    description:
      'We believe everyone deserves the opportunity to own a home with land without crushing debt. Our platform exclusively features properties under $250k.',
    icon: PiggyBank,
  },
  {
    name: 'Space to Breathe',
    description:
      'Every property in our database comes with at least 1 acre of land, giving you room to grow, build, and live life on your own terms.',
    icon: Home,
  },
  {
    name: 'Sustainable Living',
    description:
      'Properties selected for their potential to support self-sufficient living practices, from gardening to regenerative ag.',
    icon: Sprout,
  },
  {
    name: 'Community Focus',
    description:
      'Building a community of like-minded individuals pursuing affordable living and a high quality lifestyle.',
    icon: Users,
  },
  {
    name: 'Freedom & Independence',
    description:
      'Empowering people to break free from traditional housing constraints and create their ideal lifestyle.',
    icon: Sun,
  },
  {
    name: 'Quality of Life',
    description:
      'Helping families find properties that offer both affordability and the space needed for a better quality of life.',
    icon: Heart,
  },
];

export function AboutMission() {
  return (
    <div className="py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl lg:text-center">
          <h2 className="text-base font-semibold leading-7 text-primary">
            Our Mission
          </h2>
          <p className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">
            Making Affordable Country Living Accessible
          </p>
          <p className="mt-6 text-lg leading-8 text-muted-foreground">
            Through our curated property database, YouTube channel, and community platform,
            we're committed to helping people find affordable homes with land. We believe
            that everyone deserves the opportunity to own property that provides both
            space and financial freedom.
          </p>
        </div>
        <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-none">
          <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-16 lg:max-w-none lg:grid-cols-3">
            {values.map((value) => (
              <div key={value.name} className="flex flex-col">
                <dt className="flex items-center gap-x-3 text-base font-semibold">
                  <value.icon
                    className="h-5 w-5 flex-none text-primary"
                    aria-hidden="true"
                  />
                  {value.name}
                </dt>
                <dd className="mt-4 flex flex-auto flex-col text-base leading-7 text-muted-foreground">
                  <p className="flex-auto">{value.description}</p>
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
}