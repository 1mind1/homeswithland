const team = [
  {
    name: 'John Smith',
    role: 'Founder & Host',
    imageUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e',
    bio: 'Passionate about making homesteading and country living accessible to everyone. With over 10 years of experience in real estate and land development.',
  },
  {
    name: 'Sarah Johnson',
    role: 'Property Specialist',
    imageUrl: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80',
    bio: 'Expert in finding hidden gems and affordable properties across the country. Specializes in evaluating land potential and development opportunities.',
  },
  {
    name: 'Mike Williams',
    role: 'Content Creator',
    imageUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e',
    bio: 'Creating engaging content to showcase affordable properties and educate viewers about the possibilities of country living.',
  },
];

export function AboutTeam() {
  return (
    <div className="py-24 sm:py-32 bg-gray-50">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl lg:mx-0">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Meet Our Team
          </h2>
          <p className="mt-6 text-lg leading-8 text-muted-foreground">
            We're a dedicated group of professionals passionate about helping people
            find affordable properties with land. Our team combines expertise in real
            estate, land development, and content creation to make your property
            search easier.
          </p>
        </div>
        <ul
          role="list"
          className="mx-auto mt-20 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 sm:grid-cols-2 lg:mx-0 lg:max-w-none lg:grid-cols-3"
        >
          {team.map((person) => (
            <li key={person.name}>
              <img
                className="aspect-[3/2] w-full rounded-2xl object-cover"
                src={person.imageUrl}
                alt={person.name}
              />
              <h3 className="mt-6 text-lg font-semibold">{person.name}</h3>
              <p className="text-base text-primary">{person.role}</p>
              <p className="mt-4 text-base text-muted-foreground">
                {person.bio}
              </p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}