import { MapPin, Star } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import type { Agent } from '@/lib/types';

interface AgentCardProps {
  agent: Agent;
  onClick: () => void;
}

export function AgentCard({ agent, onClick }: AgentCardProps) {
  return (
    <Card 
      className="cursor-pointer hover:shadow-lg transition-shadow" 
      onClick={onClick}
      itemScope 
      itemType="http://schema.org/RealEstateAgent"
    >
      <CardHeader className="p-0">
        <div className="relative">
          {agent.featured && (
            <div className="absolute top-2 right-2">
              <Badge className="bg-yellow-400 text-black font-semibold">
                <Star className="h-3 w-3 mr-1 fill-current" />
                Featured
              </Badge>
            </div>
          )}
          <Avatar className="h-48 w-full rounded-t-lg">
            <AvatarImage src={agent.image} className="object-cover" itemProp="image" />
            <AvatarFallback>{agent.name[0]}</AvatarFallback>
          </Avatar>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <div className="space-y-2">
          <h3 className="font-semibold text-lg" itemProp="name">{agent.name}</h3>
          <p className="text-sm text-muted-foreground" itemProp="worksFor">{agent.company}</p>
          <div className="flex items-center text-sm text-muted-foreground">
            <MapPin className="h-4 w-4 mr-1" />
            <span itemProp="address">{agent.location}</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {agent.specialties.map((specialty) => (
              <Badge key={specialty} variant="secondary" itemProp="hasOfferCatalog">
                {specialty}
              </Badge>
            ))}
          </div>
          <p className="text-sm" itemProp="numberOfItems">
            {agent.listingCount} active listings
          </p>
        </div>
      </CardContent>
    </Card>
  );
}