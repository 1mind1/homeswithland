import { X, MapPin, Phone, Mail, Share2, Facebook, Instagram, Linkedin } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import type { Agent } from '@/lib/types';

interface AgentDialogProps {
  agent: Agent | null;
  open: boolean;
  onClose: () => void;
}

export function AgentDialog({ agent, open, onClose }: AgentDialogProps) {
  if (!agent) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex justify-end">
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-4 top-4"
              onClick={onClose}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Left Column */}
          <div className="space-y-6">
            <Avatar className="h-48 w-full">
              <AvatarImage src={agent.image} className="object-cover rounded-lg" />
              <AvatarFallback>{agent.name[0]}</AvatarFallback>
            </Avatar>
            
            <div>
              <h3 className="font-semibold mb-2">Contact Information</h3>
              <div className="space-y-2">
                <a href={`tel:${agent.phone}`} className="flex items-center text-sm hover:text-primary">
                  <Phone className="h-4 w-4 mr-2" />
                  {agent.phone}
                </a>
                <a href={`mailto:${agent.email}`} className="flex items-center text-sm hover:text-primary">
                  <Mail className="h-4 w-4 mr-2" />
                  {agent.email}
                </a>
                <div className="flex items-center text-sm">
                  <MapPin className="h-4 w-4 mr-2" />
                  {agent.address}
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Social Media</h3>
              <div className="flex space-x-4">
                <Button variant="ghost" size="icon">
                  <Facebook className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Instagram className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Linkedin className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div className="md:col-span-2 space-y-6">
            <div>
              <DialogTitle className="text-2xl mb-2">{agent.name}</DialogTitle>
              <p className="text-muted-foreground">{agent.company}</p>
            </div>

            <div className="flex flex-wrap gap-2">
              {agent.specialties.map((specialty) => (
                <Badge key={specialty} variant="secondary">
                  {specialty}
                </Badge>
              ))}
            </div>

            <div>
              <h3 className="font-semibold mb-2">About</h3>
              <p className="text-muted-foreground whitespace-pre-line">
                {agent.bio}
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Education</h3>
              <p className="text-muted-foreground">{agent.education}</p>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Service Areas</h3>
              <div className="flex flex-wrap gap-2">
                {agent.serviceAreas.map((area) => (
                  <Badge key={area} variant="outline">
                    {area}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="flex gap-4">
              <Button className="flex-1">Contact Agent</Button>
              <Button variant="outline" size="icon">
                <Share2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}