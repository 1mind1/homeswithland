import { useState } from 'react';
import { Search, MapPin } from 'lucide-react';
import { AgentList } from './AgentList';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Link } from '@tanstack/react-router';

interface SearchInputProps {
  icon: React.ComponentType<{ className?: string }>;
  placeholder: string;
}

function SearchInput({ icon: Icon, placeholder }: SearchInputProps) {
  return (
    <div className="flex-1 relative">
      <Icon className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
      <Input
        placeholder={placeholder}
        className="pl-9"
      />
    </div>
  );
}

export function AgentDirectory() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Find a Real Estate Agent</h1>
        <p className="mt-2 text-muted-foreground">
          Connect with experienced agents specializing in homes with land
        </p>
      </div>

      <div className="flex flex-col lg:flex-row gap-4 mb-8">
        <div className="flex-1 flex gap-4">
          <SearchInput icon={Search} placeholder="Search by name" />
          <SearchInput icon={MapPin} placeholder="Enter location" />
        </div>
        <Link to="/agents/submit">
          <Button className="w-full lg:w-auto bg-yellow-400 hover:bg-yellow-500 text-black font-semibold">
            List Your Profile
          </Button>
        </Link>
      </div>
      
      <AgentList />
    </div>
  );
}