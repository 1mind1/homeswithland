import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';

export function AgentFilters() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Specialties</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {['Residential', 'Commercial', 'Agricultural', 'Recreational'].map((specialty) => (
            <div key={specialty} className="flex items-center space-x-2">
              <Checkbox id={specialty} />
              <Label htmlFor={specialty}>{specialty}</Label>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Experience</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <div className="flex justify-between mb-2">
              <span>Years in Business</span>
              <span>5+ years</span>
            </div>
            <Slider
              defaultValue={[5]}
              max={20}
              step={1}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Property Types</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[
            'Ranches',
            'Farms',
            'Hunting Land',
            'Waterfront',
            'Mountain',
            'Development Land'
          ].map((type) => (
            <div key={type} className="flex items-center space-x-2">
              <Checkbox id={type} />
              <Label htmlFor={type}>{type}</Label>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}