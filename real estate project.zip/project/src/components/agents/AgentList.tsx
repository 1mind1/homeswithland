import { useEffect, useState } from 'react';
import { AgentCard } from './AgentCard';
import { AgentDialog } from './AgentDialog';
import type { Agent } from '@/lib/types';

const mockAgents: Agent[] = [
  {
    id: '1',
    name: 'Tyler Thomas',
    company: 'TT Ranch Group',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e',
    location: 'Dallas, TX',
    specialties: ['Agricultural', 'Commercial'],
    featured: true,
    listingCount: 30,
    bio: 'Tyler Thomas was born with a love for the outdoors, fortunate to be exposed to the lifestyle at an early age...',
    phone: '(214) 396-9692',
    email: 'tyler@ttranchgroup.com',
    address: '3131 Turtle Creek Blvd, Dallas, TX 75219',
    education: "Bachelor's from McCombs Business School at the University of Texas",
    serviceAreas: ['Texas', 'Oklahoma', 'New Mexico'],
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    company: 'Country Properties LLC',
    image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80',
    location: 'Austin, TX',
    specialties: ['Residential', 'Ranches'],
    featured: false,
    listingCount: 24,
    bio: 'With over 15 years of experience in rural properties, Sarah specializes in helping families find their perfect piece of Texas...',
    phone: '(512) 555-0123',
    email: 'sarah@countryproperties.com',
    address: '1100 Congress Ave, Austin, TX 78701',
    education: 'Real Estate Finance degree from Texas A&M University',
    serviceAreas: ['Central Texas', 'Hill Country'],
  },
  {
    id: '3',
    name: 'Michael Williams',
    company: 'Land & Ranch Realty',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e',
    location: 'Houston, TX',
    specialties: ['Recreational', 'Investment'],
    featured: true,
    listingCount: 42,
    bio: 'Michael brings a unique perspective to land sales with his background in agriculture and real estate investment...',
    phone: '(713) 555-0456',
    email: 'michael@landandranch.com',
    address: '1200 Smith St, Houston, TX 77002',
    education: 'MBA in Real Estate from Rice University',
    serviceAreas: ['Southeast Texas', 'Gulf Coast'],
  }
];

export function AgentList() {
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [agents, setAgents] = useState<Agent[]>([]);

  useEffect(() => {
    // Simulate API call
    const loadAgents = async () => {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setAgents(mockAgents);
      setIsLoading(false);
    };
    loadAgents();
  }, []);

  if (isLoading) {
    return (
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {[...Array(6)].map((_, i) => (
          <div
            key={i}
            className="h-[300px] rounded-lg bg-gray-200 animate-pulse"
          />
        ))}
      </div>
    );
  }

  return (
    <div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {agents.map((agent) => (
          <AgentCard
            key={agent.id}
            agent={agent} 
            onClick={() => setSelectedAgent(agent)}
          />
        ))}
      </div>

      <AgentDialog
        agent={selectedAgent}
        open={!!selectedAgent}
        onClose={() => setSelectedAgent(null)}
      />
    </div>
  );
}