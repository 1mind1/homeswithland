import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { toast } from 'react-hot-toast';
import { Shield, Star, Check } from 'lucide-react';

const agentSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  email: z.string().email('Invalid email address'),
  phone: z.string().min(10, 'Phone number must be at least 10 digits'),
  company: z.string().min(1, 'Company name is required'),
  location: z.string().min(1, 'Location is required'),
  bio: z.string().min(100, 'Bio must be at least 100 characters'),
  featured: z.boolean().default(false),
});

type AgentSubmissionData = z.infer<typeof agentSchema>;

const basePlan = {
  price: 79,
  features: [
    '👔 Professional profile',
    '📞 Contact info',
    '🌎 Unlimited service areas',
    '✅ Verified agent badge',
  ],
};

const featuredAddOn = {
  price: 12,
  period: '/month',
  features: [
    '🏆 Top placement in directory',
    '⭐️ Priority state listing',
    '🌟 Featured agent badge',
    '🔍 Enhanced visibility',
  ],
};

export function AgentSubmissionForm() {
  const form = useForm<AgentSubmissionData>({
    resolver: zodResolver(agentSchema),
    defaultValues: {
      featured: false,
    },
  });

  const isFeatured = form.watch('featured');
  const totalPrice = basePlan.price + (isFeatured ? featuredAddOn.price : 0);

  async function onSubmit(data: AgentSubmissionData) {
    try {
      // TODO: Implement submission logic and payment processing
      console.log('Form data:', data);
      toast.success('Redirecting to payment...');
    } catch (error) {
      toast.error('Failed to submit. Please try again.');
    }
  }

  return (
    <div className="space-y-12">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Base Plan */}
          <Card className="p-8">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h3 className="text-2xl font-bold">Agent Profile</h3>
                <p className="text-muted-foreground mt-1">Lifetime access</p>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold">${basePlan.price}</div>
                <p className="text-sm text-muted-foreground">one-time payment</p>
              </div>
            </div>

            <div className="grid gap-8 md:grid-cols-2">
              <div>
                <h4 className="font-semibold mb-4">Included Features:</h4>
                <ul className="space-y-3">
                  {basePlan.features.map((feature) => 
                    <li key={feature}>{feature}</li>
                  )}
                </ul>
              </div>

              {/* Featured Add-on */}
              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h4 className="font-semibold flex items-center gap-2">
                      <Star className="h-4 w-4 text-yellow-500" />
                      Featured Agent
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      ${featuredAddOn.price}{featuredAddOn.period}
                    </p>
                  </div>
                  <FormField
                    control={form.control}
                    name="featured"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
                <ul className="space-y-2 text-sm">
                  {featuredAddOn.features.map((feature) =>
                    <li key={feature}>{feature}</li>
                  )}
                </ul>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t">
              <div className="flex justify-between items-center mb-6">
                <div className="text-lg font-semibold">Total Price:</div>
                <div className="text-2xl font-bold">
                  ${totalPrice}
                  {isFeatured && (
                    <span className="text-sm text-muted-foreground ml-1">
                      + ${featuredAddOn.price}/month
                    </span>
                  )}
                </div>
              </div>
            </div>
          </Card>

          <div className="grid gap-6 md:grid-cols-2">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input type="email" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="company"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Company</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="location"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Primary Location</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="City, State" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="bio"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Bio</FormLabel>
                <FormControl>
                  <Textarea
                    {...field}
                    placeholder="Tell potential clients about your experience and expertise..."
                    className="h-32"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <Button type="submit" size="lg" className="w-full">
            Continue to Payment
          </Button>
        </form>
      </Form>
    </div>
  );
}