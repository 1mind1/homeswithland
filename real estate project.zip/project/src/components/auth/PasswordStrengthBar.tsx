import { useMemo } from 'react';
import { Progress } from '@/components/ui/progress';

interface PasswordStrengthBarProps {
  password: string;
}

export function PasswordStrengthBar({ password }: PasswordStrengthBarProps) {
  const strength = useMemo(() => {
    if (!password) return 0;
    
    let score = 0;
    const checks = {
      length: password.length >= 8,
      lowercase: /[a-z]/.test(password),
      uppercase: /[A-Z]/.test(password),
      number: /[0-9]/.test(password),
      special: /[^A-Za-z0-9]/.test(password),
    };

    score = Object.values(checks).filter(Boolean).length * 20;

    return score;
  }, [password]);

  const getStrengthText = () => {
    if (strength === 0) return 'No Password';
    if (strength <= 20) return 'Very Weak';
    if (strength <= 40) return 'Weak';
    if (strength <= 60) return 'Fair';
    if (strength <= 80) return 'Strong';
    return 'Very Strong';
  };

  const getStrengthColor = () => {
    if (strength <= 20) return 'bg-red-500';
    if (strength <= 40) return 'bg-orange-500';
    if (strength <= 60) return 'bg-yellow-500';
    if (strength <= 80) return 'bg-emerald-500';
    return 'bg-emerald-600';
  };

  return (
    <div className="space-y-2">
      <Progress value={strength} className={getStrengthColor()} />
      <div className="flex justify-between text-xs text-muted-foreground">
        <span>{getStrengthText()}</span>
        <span>{strength}%</span>
      </div>
    </div>
  );
}