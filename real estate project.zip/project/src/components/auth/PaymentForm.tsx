import { useState, useEffect } from 'react';
import {
  PaymentElement,
  Elements,
  useStripe,
  useElements
} from '@stripe/react-stripe-js';
import { useNavigate } from '@tanstack/react-router';
import { stripePromise } from '@/lib/stripe';
import { config } from '@/lib/config';
import { Button } from '@/components/ui/button';
import { toast } from 'react-hot-toast';

interface CheckoutFormProps {
  plan: string;
}

function CheckoutForm({ plan }: CheckoutFormProps) {
  const stripe = useStripe();
  const elements = useElements();
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string>();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    setIsProcessing(true);
    setError(undefined);

    try {
      const { error: paymentError } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/signup/${plan}/account`,
        },
      });

      if (paymentError) {
        setError(paymentError.message);
        toast.error(paymentError.message || 'Payment failed');
      }
    } catch (error) {
      setError('Payment processing failed');
      toast.error('Payment failed. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      {error && (
        <p className="text-sm text-red-600">{error}</p>
      )}
      <Button 
        type="submit" 
        className="w-full"
        disabled={isProcessing || !stripe || !elements}
      >
        {isProcessing ? 'Processing...' : 'Pay Now'}
      </Button>
    </form>
  );
}

interface PaymentFormProps {
  plan: string;
}

export function PaymentForm({ plan }: PaymentFormProps) {
  const [clientSecret, setClientSecret] = useState<string>();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string>();
  const navigate = useNavigate(); 

  const handlePaymentError = (error: Error) => {
    const message = error.message || 'Payment initialization failed';
    console.error('Payment initialization error:', error);
    setError(message);
    toast.error(message);
  };

  useEffect(() => {
    setIsLoading(true);
    setError(undefined);

    const fetchPaymentIntent = async () => {
      try {
        const requestBody = { plan: plan.toLowerCase() };
        const endpoint = config.api.endpoints.createPaymentIntent;

        const response = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify(requestBody)
        });

        const data = await response.json();
        
        if (!response.ok) {
          throw new Error(data.error || 'Payment initialization failed');
        }

        if (!data.clientSecret) {
          throw new Error('Invalid response: missing client secret');
        }

        setClientSecret(data.clientSecret);
      } catch (error) {
        handlePaymentError(error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchPaymentIntent();
  }, [plan]);

  if (isLoading) {
    return (
      <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-lg shadow-lg">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-sm text-muted-foreground">Initializing payment...</p>
        </div>
      </div>
    );
  }

  if (error || !clientSecret) {
    return (
      <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-lg shadow-lg">
        <div className="text-center text-red-600">
          <p>{error || 'Unable to initialize payment. Please try again.'}</p>
          <Button 
            onClick={() => window.location.reload()} 
            className="mt-4"
          >
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-lg shadow-lg">
      <div className="space-y-2 text-center">
        <h1 className="text-2xl font-bold">Subscribe to {plan}</h1>
        <p className="text-gray-500">Enter your payment information</p>
      </div>

      <Elements 
        stripe={stripePromise}
        options={{ 
          clientSecret,
          appearance: {
            theme: 'stripe',
            variables: {
              colorPrimary: '#0f172a',
            },
          },
        }}
      >
        <CheckoutForm plan={plan} />
      </Elements>
    </div>
  );
}