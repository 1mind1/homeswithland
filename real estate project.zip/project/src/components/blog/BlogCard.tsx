import { Link } from '@tanstack/react-router';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import type { BlogPost } from '@/lib/types';

interface BlogCardProps {
  post: BlogPost;
}

export function BlogCard({ post }: BlogCardProps) {
  return (
    <Card className="overflow-hidden">
      <CardHeader className="p-0">
        <Link to="/blog/$slug" params={{ slug: post.slug || '' }}>
          <img
            src={`https://source.unsplash.com/featured/800x400?${post.category}`}
            alt={post.title}
            className="w-full h-48 object-cover transition-transform hover:scale-105"
          />
        </Link>
      </CardHeader>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-3">
          <Badge variant="secondary">{post.category}</Badge>
          <time className="text-sm text-muted-foreground">
            {format(new Date(post.createdAt), 'MMM d, yyyy')}
          </time>
        </div>
        <Link
          to="/blog/$slug" 
          params={{ slug: post.slug }}
          className="block group"
        >
          <h2 className="text-xl font-semibold group-hover:text-primary">
            {post.title}
          </h2>
        </Link>
        <p className="mt-2 text-muted-foreground line-clamp-3">
          {post.content}
        </p>
      </CardContent>
    </Card>
  );
}