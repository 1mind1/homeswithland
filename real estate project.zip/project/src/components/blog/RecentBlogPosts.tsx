import { useQuery } from '@tanstack/react-query';
import { Link } from '@tanstack/react-router';
import { format } from 'date-fns';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase';
import type { BlogPost } from '@/lib/types';

export function RecentBlogPosts() {
  const { data: posts, isLoading } = useQuery({
    queryKey: ['recentBlogPosts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('blog_posts')
        .select('*')
        .eq('published', true)
        .order('created_at', { ascending: false })
        .limit(3);

      if (error) throw error;

      return data.map((post) => ({
        ...post,
        createdAt: post.created_at,
        updatedAt: post.updated_at,
      })) as BlogPost[];
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        <h2 className="text-2xl font-bold tracking-tight">Recent Blog Posts</h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              className="h-[200px] rounded-lg bg-gray-200 animate-pulse"
            />
          ))}
        </div>
      </div>
    );
  }

  if (!posts?.length) return null;

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold tracking-tight">Recent Blog Posts</h2>
        <Link to="/blog">
          <Button variant="ghost">
            View all posts
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {posts.map((post) => (
          <article
            key={post.id}
            className="rounded-lg border bg-card text-card-foreground shadow-sm"
          >
            <div className="p-6">
              <time
                dateTime={post.createdAt}
                className="text-sm text-muted-foreground"
              >
                {format(new Date(post.createdAt), 'MMMM d, yyyy')}
              </time>
              <Link
                to="/blog/$slug"
                params={{ slug: post.slug }}
                className="mt-2 block"
              >
                <h3 className="text-xl font-semibold leading-6 text-gray-900 hover:text-primary">
                  {post.title}
                </h3>
              </Link>
              <Badge className="mt-2">{post.category}</Badge>
              <p className="mt-3 text-sm leading-6 text-muted-foreground line-clamp-3">
                {post.content}
              </p>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}