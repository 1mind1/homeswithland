import { MapPin, Mail, Phone, Youtube } from 'lucide-react';
import { Button } from '@/components/ui/button';

const contactMethods = [
  {
    icon: Mail,
    label: 'Email',
    value: 'info@homeswith.land',
    href: 'mailto:info@homeswith.land',
  },
  {
    icon: Youtube,
    label: 'YouTube',
    value: '@homeswithland',
    href: 'https://www.youtube.com/@homeswithland',
  },
];

export function ContactInfo() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-semibold tracking-tight">Get in Touch</h2>
        <p className="mt-4 text-muted-foreground">
          Whether you're looking for your dream property or have questions about
          country living, we're here to help.
        </p>
      </div>

      <div className="space-y-4">
        {contactMethods.map((method) => (
          <div
            key={method.label}
            className="flex items-start space-x-4 rounded-lg p-4 transition-colors hover:bg-muted"
          >
            <method.icon className="mt-1 h-5 w-5 text-primary" />
            <div className="space-y-1">
              <p className="text-sm font-medium">{method.label}</p>
              <Button
                variant="link"
                className="h-auto p-0 text-base"
                onClick={() => window.open(method.href, '_blank')}
              >
                {method.value}
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}