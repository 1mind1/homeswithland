import { ArrowRight } from 'lucide-react';
import { Link } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';

export function AgentDirectorySection() {
  return (
    <div className="py-24 sm:py-32 bg-yellow-50">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl lg:text-center">
          <h2 className="text-base font-semibold leading-7 text-yellow-600">
            Expert Guidance
          </h2>
          <p className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">
            Connect with Specialized Agents
          </p>
          <p className="mt-6 text-lg leading-8 text-muted-foreground">
            Work with agents who understand the unique aspects of land and acreage properties. 
            Our directory features experienced professionals across all 50 states.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/agents">
              <Button size="lg" className="gap-2 bg-yellow-400 hover:bg-yellow-500 text-black font-semibold">
                Find an Agent
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link to="/agents/submit">
              <Button size="lg" variant="outline" className="gap-2 border-yellow-400 text-yellow-700 hover:bg-yellow-50">
                Join Our Directory
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>

        <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-none">
          <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-16 lg:max-w-none lg:grid-cols-3">
            {[
              {
                stat: '300+',
                label: 'Active Agents',
                description: 'Experienced professionals specializing in land and acreage properties.',
                className: 'text-yellow-600',
              },
              {
                stat: '50',
                label: 'States Covered',
                description: 'Find local expertise in any state across the country.',
                className: 'text-yellow-600',
              },
              {
                stat: '4,000+',
                label: 'Properties Sold',
                description: 'Proven track record of helping clients find their perfect property.',
                className: 'text-yellow-600',
              },
            ].map((item) => (
              <div key={item.label} className="flex flex-col">
                <dt className="text-base font-semibold leading-7 text-gray-900">
                  <div className={`mb-2 text-2xl font-bold ${item.className}`}>{item.stat}</div>
                  {item.label}
                </dt>
                <dd className="mt-1 flex flex-auto flex-col text-base leading-7 text-muted-foreground">
                  <p className="flex-auto">{item.description}</p>
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
}