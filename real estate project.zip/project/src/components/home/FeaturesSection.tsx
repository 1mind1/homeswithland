import {
  Home,
  PiggyBank,
  Search,
  Mail,
  Map,
  Shield,
} from 'lucide-react';

const features = [
  {
    name: 'Affordable Living',
    description:
      'Find spacious homes with land at affordable prices, breaking free from overpriced cookie-cutter neighborhoods.',
    icon: PiggyBank,
  },
  {
    name: 'Curated Database',
    description:
      'Every property in our database is reviewed to ensure it meets our strict affordability and land requirements.',
    icon: Home,
  },
  {
    name: 'Nationwide Coverage',
    description:
      'Access properties across all 50 states and 3,000+ counties, giving you the freedom to find your ideal location.',
    icon: Map,
  },
  {
    name: 'Smart Search Tools',
    description:
      'Easily filter properties by acreage, price, and location to find exactly what you are looking for.',
    icon: Search,
  },
  {
    name: 'Property Insights',
    description:
      'Get detailed property information, including land use, utilities, and potential development opportunities.',
    icon: Shield,
  },
  {
    name: 'Regular Updates',
    description:
      'Stay informed with our newsletter featuring new properties and market trends in affordable opportunities.',
    icon: Mail,
  },
];

export function FeaturesSection() {
  return (
    <div className="py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl px-4 sm:px-6 text-center">
          <h2 className="text-base font-semibold leading-7 text-primary">
            Find Your Space
          </h2>
          <p className="mt-2 text-2xl sm:text-3xl font-bold tracking-tight text-gray-900 lg:text-4xl">
            Break Free from Overpriced Cookie-Cutter Homes
          </p>
          <p className="mt-6 text-lg leading-8 text-gray-600">
            Discover homes that offer both affordability and space. Our curated database 
            features properties that give you room to breathe without breaking the bank.
          </p>
        </div>
        <div className="mx-auto mt-12 sm:mt-16 lg:mt-24">
          <dl className="grid grid-cols-1 gap-6 sm:gap-8 md:grid-cols-2 lg:grid-cols-3">
            {features.map((feature) => (
              <div key={feature.name} className="flex flex-col">
                <dt className="flex items-center gap-x-3 text-base font-semibold leading-7 text-gray-900">
                  <feature.icon
                    className="h-5 w-5 flex-none text-primary"
                    aria-hidden="true"
                  />
                  {feature.name}
                </dt>
                <dd className="mt-4 flex flex-auto flex-col text-base leading-7 text-gray-600">
                  <p className="flex-auto">{feature.description}</p>
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
}