import { useEffect } from 'react';
import { ArrowRight, PlayCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link, useNavigate } from '@tanstack/react-router';
import { preloadImage } from '@/lib/utils';
import { useAuth } from '@/hooks/useAuth';

export function HeroSection() {
  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => {
    // Preload hero image
    preloadImage('https://images.unsplash.com/photo-1713322957180-5a7d9ef6ebc6');
  }, []);

  const handlePropertiesClick = () => {
    if (!user) {
      navigate({ 
        to: '/signin',
        search: { redirect: '/properties' }
      });
      return;
    }
    navigate({ to: '/properties' });
  };

  return (
    <div className="relative isolate">
      {/* Background image */}
      <div className="absolute inset-0 -z-10">
        <img
          src="https://images.unsplash.com/photo-1713322957180-5a7d9ef6ebc6?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
          alt="house and barn on 20 acres"
          className="h-full w-full object-cover brightness-50"
          loading="eager"
          fetchpriority="high"
        />
      </div>

      {/* Content */}
      <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
        <div className="mx-auto max-w-2xl lg:mx-0 text-center lg:text-left">
          <div className="hidden sm:mb-8 sm:flex">
            <div className="relative rounded-full px-3 py-1 text-sm leading-6 text-white ring-1 ring-white/10 hover:ring-white/20">
              New properties added daily!{' '}
              <Link to="/properties" className="font-semibold text-white">
                <span className="absolute inset-0" aria-hidden="true" />
                View latest <span aria-hidden="true">&rarr;</span>
              </Link>
            </div>
          </div>
          <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl">
            Your Dream Property
            <br />
            Awaits Discovery
          </h1>
          <p className="mt-6 text-lg leading-8 text-gray-300">
            Find your perfect piece of comfort with our curated selection of affordable properties.
            From large acre farm houses to serene lakefront acreage, your future home with land is just a click away.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row items-center gap-4 sm:gap-x-6">
            <Button 
              size="lg" 
              className="w-full bg-white text-gray-900 hover:bg-gray-100"
              onClick={handlePropertiesClick}
            >
              Browse Properties
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="lg"
              className="text-white hover:bg-red-600/90 bg-red-600"
              onClick={() => {
                window.open('https://www.youtube.com/@homeswithland', '_blank');
              }}
            >
              <PlayCircle className="mr-2 h-5 w-5" />
              <span className="hidden sm:inline">Check Out Our YouTube Channel</span>
              <span className="sm:hidden">YouTube Channel</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="bg-black/50 backdrop-blur-sm">
        <div className="mx-auto max-w-7xl px-6 lg:px-8 py-8">
          <dl className="grid grid-cols-2 gap-x-4 gap-y-6 text-center sm:gap-x-8 lg:grid-cols-4">
            {[
              { label: 'Active Listings', value: '1,500+' },
              { label: 'Available Combined Acres', value: '10,000+' },
              { label: 'States Covered', value: '50' },
              { label: 'Counties Covered', value: '3,144+' },
            ].map((stat) => (
              <div key={stat.label} className="mx-auto flex flex-col gap-y-2">
                <dt className="text-sm leading-6 text-gray-300">{stat.label}</dt>
                <dd className="text-3xl font-semibold tracking-tight text-white">
                  {stat.value}
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
}