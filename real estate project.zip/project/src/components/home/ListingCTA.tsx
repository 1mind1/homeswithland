import { ArrowRight, Home, DollarSign, CheckCircle } from 'lucide-react';
import { Link } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';

export function ListingCTA() {
  return (
    <div className="py-24 sm:py-32 bg-primary/5">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl lg:text-center">
          <h2 className="text-base font-semibold leading-7 text-primary">
            List Your Property
          </h2>
          <p className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">
            Have a Property to Sell?
          </p>
          <p className="mt-6 text-lg leading-8 text-muted-foreground">
            Join our community of sellers and reach thousands of potential buyers looking for their perfect piece of land.
          </p>
        </div>

        <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-none">
          <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-16 lg:max-w-none lg:grid-cols-3">
            {[
              {
                icon: Home,
                name: 'Targeted Exposure',
                description:
                  'Reach buyers specifically looking for properties with land and acreage.',
              },
              {
                icon: DollarSign,
                name: 'Fair Pricing',
                description:
                  'Set your own price and connect directly with serious buyers.',
              },
              {
                icon: CheckCircle,
                name: 'Simple Process',
                description:
                  'Easy listing creation with support for multiple photos and detailed property information.',
              },
            ].map((feature) => (
              <div key={feature.name} className="flex flex-col">
                <dt className="flex items-center gap-x-3 text-base font-semibold leading-7">
                  <feature.icon
                    className="h-5 w-5 flex-none text-primary"
                    aria-hidden="true"
                  />
                  {feature.name}
                </dt>
                <dd className="mt-4 flex flex-auto flex-col text-base leading-7 text-muted-foreground">
                  <p className="flex-auto">{feature.description}</p>
                </dd>
              </div>
            ))}
          </dl>

          <div className="mt-16 flex justify-center">
            <Link to="/plans">
              <Button size="lg" className="gap-2 bg-yellow-400 hover:bg-yellow-500 text-black font-semibold">
                List Your Property Now
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}