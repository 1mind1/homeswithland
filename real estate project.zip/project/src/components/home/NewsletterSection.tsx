import { useState } from 'react';
import { Mail, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'react-hot-toast';

export function NewsletterSection() {
  const [isLoading, setIsLoading] = useState(false);
  const [firstName, setFirstName] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      // Add newsletter subscription logic here
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulated API call
      toast.success('Successfully subscribed to newsletter!');
      setFirstName('');
      setEmail('');
    } catch (error) {
      toast.error('Failed to subscribe. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="py-24 sm:py-32 bg-gray-50">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid gap-16 lg:grid-cols-2">
          {/* Left Column - Free Newsletter */}
          <div className="bg-white p-8 rounded-lg shadow-lg">
            <div className="flex items-center gap-3 text-primary mb-6">
              <Mail className="h-6 w-6" />
              <h3 className="text-xl font-semibold">Free Weekly Newsletter</h3>
            </div>
            <div className="space-y-4">
              <p className="text-muted-foreground">
                Stay updated with a curated selection of affordable properties delivered to your inbox every week.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                  <span>3 featured properties weekly</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                  <span>Basic property details</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                  <span>Official property listings</span>
                </li>
              </ul>
              <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Input
                    type="text"
                    placeholder="First Name"
                    required
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    disabled={isLoading}
                  />
                  <Input
                    type="email"
                    placeholder="Email Address"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled={isLoading}
                  />
                </div>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Subscribing...
                    </>
                  ) : (
                    'Subscribe For Free'
                  )}
                </Button>
              </form>
            </div>
          </div>

          {/* Right Column - Premium Newsletter */}
          <div className="bg-primary text-primary-foreground p-8 rounded-lg shadow-lg">
            <div className="flex items-center gap-3 mb-6">
              <Mail className="h-6 w-6" />
              <h3 className="text-xl font-semibold">Premium Newsletter</h3>
            </div>
            <div className="space-y-4">
              <p className="text-primary-foreground/90">
                Upgrade to a premium plan for access to our property database and exclusive newsletters.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-white" />
                  <span>Properties added daily</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-white" />
                  <span>Exclusive access to 1,500+ properties</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-white" />
                  <span>Direct contact with agents & sellers</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-white" />
                  <span>Property analysis reports</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-white" />
                  <span>Early access to new listings</span>
                </li>
              </ul>
              <div className="mt-6">
                <Button
                  variant="secondary"
                  className="w-full bg-white text-primary hover:bg-gray-100"
                  onClick={() => window.location.href = '/plans?tab=subscribe'}
                >
                  Upgrade to Premium
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}