import { Button } from '@/components/ui/button';
import { Youtube, PlayCircle } from 'lucide-react';

export function YouTubeSection() {
  return (
    <div className="relative isolate overflow-hidden bg-gray-900 py-24 sm:py-32">
      {/* Background gradients */}
      <div className="hidden sm:absolute sm:-top-10 sm:right-1/2 sm:-z-10 sm:mr-10 sm:block sm:transform-gpu sm:blur-3xl">
        <div
          className="aspect-[1097/845] w-[68.5625rem] bg-gradient-to-tr from-[#ff4694] to-[#776fff] opacity-20"
          style={{
            clipPath:
              'polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)',
          }}
        />
      </div>
      <div className="absolute -top-52 left-1/2 -z-10 -translate-x-1/2 transform-gpu blur-3xl sm:top-[-28rem] sm:ml-16 sm:translate-x-0 sm:transform-gpu">
        <div
          className="aspect-[1097/845] w-[68.5625rem] bg-gradient-to-tr from-[#ff4694] to-[#776fff] opacity-20"
          style={{
            clipPath:
              'polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)',
          }}
        />
      </div>
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-2xl lg:max-w-xl">
            <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-6xl">
              Join Our YouTube Community
            </h2>
            <p className="mt-6 text-lg leading-8 text-gray-300">
              Subscribe to our channel for daily featured properties!
            </p>
            <div className="mt-10 flex flex-col sm:flex-row items-center gap-4">
              <Button
                size="lg"
                className="w-full sm:w-auto bg-red-600 hover:bg-red-700 text-white"
                onClick={() => {
                  window.open('https://www.youtube.com/@homeswithland', '_blank');
                }}
              >
                <Youtube className="mr-2 h-5 w-5" />
                Subscribe Now
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="w-full sm:w-auto bg-white text-gray-900"
                onClick={() => {
                  window.open('https://www.youtube.com/@homeswithland/videos', '_blank');
                }}
              >
                <PlayCircle className="mr-2 h-5 w-5" />
                <span className="hidden sm:inline">Watch Latest Videos</span>
                <span className="sm:hidden">Watch Videos</span>
              </Button>
            </div>
          </div>
          <div className="mt-10 lg:mt-0 lg:ml-8">
            <img
              src="https://ucarecdn.com/23107710-1eda-4201-a3f5-88f0fbdba29c/Affordable.png"
              alt="Affordable Homes with Land"
              className="max-w-sm"
            />
          </div>
        </div>
        <div className="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-6 sm:grid-cols-2 sm:mt-20 lg:mx-0 lg:max-w-none lg:grid-cols-3 lg:gap-8">
          {[
            {
              title: 'Property Tours',
              description: 'Short but detailed overviews of select properties across the US with detailed commentary.',
            },
            {
              title: 'Specialized Agents',
              description: 'We feature specialized agents from across the US that can help you hunt for affordable, hidden gems.',
            },
            {
              title: 'Success Stories',
              description: 'Hear from happy customers who found their perfect property.',
            },
          ].map((stat) => (
            <div
              key={stat.title}
              className="flex gap-x-4 rounded-xl bg-white/5 p-6 ring-1 ring-inset ring-white/10"
            >
              <div className="text-base leading-7">
                <h3 className="font-semibold text-white">{stat.title}</h3>
                <p className="mt-2 text-gray-300">{stat.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}