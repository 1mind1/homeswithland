import { useState } from 'react';
import { Link, useNavigate } from '@tanstack/react-router';
import { Home, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from '@/components/ui/sheet';
import { useAuth } from '@/hooks/useAuth';

export function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  const navigation = [
    { name: 'Home', href: '/' },
    { name: 'About', href: '/about' },
  ];

  const handlePropertiesClick = () => {
    if (!user) {
      navigate({ 
        to: '/signin',
        search: { redirect: '/properties' }
      });
      return;
    }
    navigate({ to: '/properties' });
  };

  return (
    <header className="bg-white shadow-sm">
      <nav className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8" aria-label="Top">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <Home className="h-8 w-8 text-primary" />
              <span className="text-xl font-bold hidden sm:inline">Affordable Homes with Land</span>
              <span className="text-xl font-bold sm:hidden">Homes with Land</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex lg:items-center lg:space-x-6">
            {navigation.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className="text-sm font-medium text-gray-700 hover:text-primary"
              >
                {item.name}
              </Link>
            ))}
            <Button
              variant="ghost"
              className="text-sm font-medium text-gray-700 hover:text-primary"
              onClick={handlePropertiesClick}
            >
              Properties
            </Button>
            {user ? (
              <>
                <Link to="/dashboard">
                  <Button variant="ghost">Dashboard</Button>
                </Link>
                <Link to="/plans">
                  <Button className="bg-yellow-400 hover:bg-yellow-500 text-black font-semibold">
                    List Your Property
                  </Button>
                </Link>
                <Button variant="ghost" onClick={() => signOut()}>
                  Sign Out
                </Button>
              </>
            ) : (
              <>
                <Link to="/signin">
                  <Button variant="secondary" className="bg-blue-100 hover:bg-blue-200 text-blue-700">Login</Button>
                </Link>
                <Link to="/plans" search={{ tab: 'subscribe' }}>
                  <Button variant="outline">Sign Up</Button>
                </Link>
                <Link to="/plans">
                  <Button className="bg-yellow-400 hover:bg-yellow-500 text-black font-semibold">
                    List Your Property
                  </Button>
                </Link>
              </>
            )}
          </div>

          {/* Mobile Navigation */}
          <div className="lg:hidden">
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  {isOpen ? (
                    <X className="h-6 w-6 text-yellow-400" />
                  ) : (
                    <Menu className="h-6 w-6 text-yellow-400" />
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <div className="mt-6 flow-root">
                  <div className="space-y-4">
                    {navigation.map((item) => (
                      <Link
                        key={item.name}
                        to={item.href}
                        className="block px-3 py-2 text-base font-medium text-gray-700 hover:bg-gray-50"
                        onClick={() => setIsOpen(false)}
                      >
                        {item.name}
                      </Link>
                    ))}
                    {user ? (
                      <>
                        <Link
                          to="/dashboard"
                          className="block px-3 py-2 text-base font-medium text-gray-700 hover:bg-gray-50"
                          onClick={() => setIsOpen(false)}
                        >
                          Dashboard
                        </Link>
                        <Link
                          to="/plans"
                          onClick={() => setIsOpen(false)}
                        >
                          <Button className="w-full bg-yellow-400 hover:bg-yellow-500 text-black font-semibold">
                            List Your Property
                          </Button>
                        </Link>
                        <Button
                          variant="outline"
                          className="w-full"
                          onClick={() => {
                            signOut();
                            setIsOpen(false);
                          }}
                        >
                          Sign Out
                        </Button>
                      </>
                    ) : (
                      <>
                        <Link
                          to="/signin"
                          onClick={() => setIsOpen(false)}
                        >
                          <Button variant="secondary" className="w-full bg-blue-100 hover:bg-blue-200 text-blue-700">
                            Login
                          </Button>
                        </Link>
                        <Link to="/plans" search={{ tab: 'subscribe' }} onClick={() => setIsOpen(false)}>
                          <Button className="w-full">Sign Up</Button>
                        </Link>
                        <Link
                          to="/plans"
                          onClick={() => setIsOpen(false)}
                        >
                          <Button className="w-full bg-yellow-400 hover:bg-yellow-500 text-black font-semibold">
                            List Your Property
                          </Button>
                        </Link>
                      </>
                    )}
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </nav>
    </header>
  );
}