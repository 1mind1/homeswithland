import { Check, Crown, Star, Rocket, Shield } from 'lucide-react';
import { Link } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';

const plans = [
  {
    name: 'Standard',
    price: 99.99,
    description: 'Perfect for single property listings',
    icon: Shield,
    iconClass: 'text-blue-500',
    features: [
      '🏠 Added to our property database',
      '📸 Optional 3rd party listing linking',
      '📝 Detailed description, photos, & contact info',
      '📧 Featured in weekly newsletter',
      '⏰ Lifetime listing duration',
    ],
  },
  {
    name: 'Premium',
    price: 149.99,
    description: 'Best for maximum exposure',
    icon: Crown,
    iconClass: 'text-yellow-500',
    features: [
      '✨ Everything in Standard, plus:',
      '🌟 Featured property badge',
      '📊 Top search placement',
      '🎥 YouTube video creation',
      '👥 25,000+ targeted views',
      '⚡️ Buyer lead generation',
    ],
    featured: true,
  },
];

export function PricingPlans() {
  return (
    <div className="mt-8 sm:mt-16 grid max-w-lg grid-cols-1 gap-6 sm:gap-8 mx-auto lg:max-w-3xl lg:grid-cols-2 justify-center">
      {plans.map((plan) => {
        const Icon = plan.icon;
        return (
          <Card
            key={plan.name}
            className={`relative flex flex-col ${
              plan.featured 
                ? 'border-primary shadow-lg scale-105 before:absolute before:-inset-1.5 before:rounded-[inherit] before:border-2 before:border-primary/50 before:opacity-50' 
                : ''
            }`}
          >
            <CardHeader className="flex-none space-y-2">
              {plan.featured && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <span className="bg-primary text-primary-foreground text-sm font-medium px-3 py-1 rounded-full flex items-center gap-1">
                    <Star className="h-3.5 w-3.5 fill-current" />
                    Most Popular
                  </span>
                </div>
              )}
              <div className={`w-12 h-12 rounded-lg bg-${plan.iconClass}/10 flex items-center justify-center mb-2`}>
                <Icon className={`h-6 w-6 ${plan.iconClass}`} />
              </div>
              <CardTitle className="text-2xl">{plan.name}</CardTitle>
              <div className="flex items-baseline">
                <span className="text-3xl font-bold">${plan.price}</span>
              </div>
              <CardDescription>{plan.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-grow">
              <ul className="space-y-3 text-[15px]">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-3">
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Link
                to="/submit-property"
                className="w-full"
                search={{ plan: plan.name.toLowerCase() }}
              >
                <Button
                  className={`w-full ${
                    plan.featured
                      ? 'bg-primary hover:bg-primary/90'
                      : 'bg-primary/10 hover:bg-primary/20 text-primary'
                  }`}
                >
                  Get Started
                </Button>
              </Link>
            </CardFooter>
          </Card>
        );
      })}
    </div>
  );
}