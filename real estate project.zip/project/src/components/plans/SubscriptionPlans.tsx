import { Check, Crown, Infinity, Star, Zap } from 'lucide-react';
import { Link } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';

const plans = [
  {
    name: 'Monthly',
    price: 5.79,
    period: '/mo',
    description: '🔍 Start exploring your dream property',
    icon: Zap,
    iconClass: 'text-blue-500',
    features: [
      '🏠 Access to all property listings',
      '📱 Mobile-friendly property search',
      '❤️ Save favorite properties',
      '📧 Contact property owners',
      '📬 Monthly newsletter',
      '🤝 Community access',
    ],
  },
  {
    name: 'Annual',
    price: 59.00,
    period: '/year',
    description: '💫 Most popular - Save 20%!',
    icon: Crown,
    iconClass: 'text-yellow-500',
    features: [
      '🌟 Everything in Monthly, plus:',
      '⚡️ Early access to new listings',
      '🎯 Personalized property alerts',
      '📊 Market analysis reports',
      '🎓 Expert webinars & training',
      '⭐️ Priority support access',
    ],
    featured: true,
  },
  {
    name: 'Lifetime',
    price: 129.99,
    period: '',
    description: '🌟 Ultimate value - One-time payment!',
    icon: Infinity,
    iconClass: 'text-purple-500',
    features: [
      '👑 Everything in Annual, plus:',
      '💎 Lifetime unlimited access',
      '🎥 Exclusive video content',
      '🎖️ VIP support',
      '🌟 Elite member badge',
      '🎉 VIP event invitations',
      '💫 Personal property concierge',
    ],
  },
];

export function SubscriptionPlans() {
  return (
    <div className="mt-8 sm:mt-16 grid max-w-lg grid-cols-1 gap-6 sm:gap-8 mx-auto lg:max-w-7xl lg:grid-cols-3">
      {plans.map((plan) => {
        const Icon = plan.icon;
        return (
          <Card
            key={plan.name}
            className={`relative flex flex-col ${
              plan.featured 
                ? 'border-primary shadow-lg scale-105 before:absolute before:-inset-1.5 before:rounded-[inherit] before:border-2 before:border-primary/50 before:opacity-50' 
                : ''
            }`}
          >
            <CardHeader className="flex-none space-y-2">
              {plan.featured && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <span className="bg-primary text-primary-foreground text-sm font-medium px-3 py-1 rounded-full flex items-center gap-1">
                    <Star className="h-3.5 w-3.5 fill-current" />
                    Most Popular
                  </span>
                </div>
              )}
              <div className={`w-12 h-12 rounded-lg bg-${plan.iconClass}/10 flex items-center justify-center mb-2`}>
                <Icon className={`h-6 w-6 ${plan.iconClass}`} />
              </div>
              <CardTitle className="text-2xl">{plan.name}</CardTitle>
              <div className="flex items-baseline">
                <span className="text-3xl font-bold">${plan.price}</span>
                <span className="text-muted-foreground">{plan.period}</span>
              </div>
              <CardDescription>{plan.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-grow">
              <ul className="space-y-3 text-[15px]">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-3">
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Link
                to="/signup/$plan/payment"
                params={{ plan: plan.name.toLowerCase() }}
                className="w-full"
              >
                <Button
                  className={`w-full ${
                    plan.featured
                      ? 'bg-primary hover:bg-primary/90'
                      : 'bg-primary/10 hover:bg-primary/20 text-primary'
                  }`}
                >
                  Get Started
                </Button>
              </Link>
            </CardFooter>
          </Card>
        );
      })}
    </div>
  );
}