import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from '@tanstack/react-router';
import { Home } from 'lucide-react';
import { PropertyCard } from './PropertyCard';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import type { Property } from '@/lib/types';
import { Button } from '@/components/ui/button';

const FALLBACK_IMAGES = [
  'https://images.unsplash.com/photo-1564013799919-ab600027ffc6',
  'https://images.unsplash.com/photo-1568605114967-8130f3a36994',
  'https://images.unsplash.com/photo-1523217582562-09d0def993a6',
  'https://images.unsplash.com/photo-1512917774080-9991f1c4c750'
];
export function FeaturedProperties() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: properties, isLoading } = useQuery({
    queryKey: ['featuredProperties'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('properties')
        .select(`
          *,
          property_images(*)
        `)
        .eq('featured', true)
        .eq('status', 'approved')
        .limit(3);

      if (error) throw error;

      return data.map((property) => ({
        ...property,
        images: property.property_images?.length ? property.property_images.map(img => ({
          id: img.id,
          propertyId: img.property_id,
          url: img.url,
          isPrimary: img.is_primary
        })) : [{
          id: `fallback-${index}`,
          propertyId: property.id,
          url: FALLBACK_IMAGES[index % FALLBACK_IMAGES.length],
          isPrimary: true
        }],
        createdAt: property.created_at,
        updatedAt: property.updated_at,
      })) as Property[];
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-6">
          <Home className="h-6 w-6 text-primary" />
          <h2 className="text-2xl font-bold tracking-tight">Featured Properties</h2>
        </div>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              className="h-[400px] rounded-lg bg-gray-100 animate-pulse"
            />
          ))}
        </div>
      </div>
    );
  }

  if (!properties?.length) return null;

  const handleViewAll = () => {
    if (!user) {
      navigate({ 
        to: '/signin',
        search: { redirect: '/properties' }
      });
      return;
    }
    navigate({ to: '/properties' });
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Home className="h-6 w-6 text-primary" />
          <h2 className="text-2xl font-bold tracking-tight">Featured Properties</h2>
        </div>
        <Button onClick={handleViewAll}>
          View All Properties
        </Button>
      </div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {properties.map((property) => (
          <PropertyCard key={property.id} property={property} />
        ))}
      </div>
      {!user && (
        <div className="text-center mt-8">
          <p className="text-muted-foreground mb-4">
            Sign up to view our full collection of properties with land
          </p>
          <Button
            onClick={() => navigate({ to: '/plans', search: { tab: 'subscribe' } })}
            className="bg-primary"
          >
            Get Started
          </Button>
        </div>
      )}
    </div>
  );
}