import { Link } from '@tanstack/react-router';
import { MapPin, Ruler, Bath, Bed } from 'lucide-react';
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AspectRatio } from '@/components/ui/aspect-ratio';
import type { Property } from '@/lib/types';

interface PropertyCardProps {
  property: Property;
}

export function PropertyCard({ property }: PropertyCardProps) {
  const primaryImage = property.images.find((img) => img.isPrimary)?.url;
  const formatter = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  });

  return (
    <Card className="overflow-hidden">
      <CardHeader className="p-0">
        <Link to="/properties/$propertyId" params={{ propertyId: property.id }}>
          <AspectRatio ratio={16 / 9}>
            <img
              src={primaryImage || 'https://images.unsplash.com/photo-1628744876497-eb30460be9c6'}
              loading="lazy"
              decoding="async"
              alt={property.title}
              className="object-cover w-full h-full transition-transform hover:scale-105"
            />
          </AspectRatio>
        </Link>
      </CardHeader>
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-semibold line-clamp-1">{property.title}</h3>
          <Badge variant="secondary">{formatter.format(property.price)}</Badge>
        </div>
        <div className="flex items-center text-sm text-muted-foreground mb-4">
          <MapPin className="h-4 w-4 mr-1" />
          <span>{property.location}</span>
        </div>
        <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
          {property.description}
        </p>
      </CardContent>
      <CardFooter className="px-4 py-3 border-t flex justify-between">
        <div className="flex items-center text-sm">
          <Ruler className="h-4 w-4 mr-1" />
          <span>{property.acres} acres</span>
        </div>
        {(property.bedrooms > 0 || property.bathrooms > 0) && (
          <div className="flex gap-3">
            {property.bedrooms > 0 && (
              <div className="flex items-center text-sm">
                <Bed className="h-4 w-4 mr-1" />
                <span>{property.bedrooms}</span>
              </div>
            )}
            {property.bathrooms > 0 && (
              <div className="flex items-center text-sm">
                <Bath className="h-4 w-4 mr-1" />
                <span>{property.bathrooms}</span>
              </div>
            )}
          </div>
        )}
      </CardFooter>
    </Card>
  );
}