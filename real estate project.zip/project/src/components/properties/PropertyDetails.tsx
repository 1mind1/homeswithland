import { useState } from 'react';
import { format } from 'date-fns';
import {
  Bath,
  Bed,
  Calendar,
  Heart,
  Mail,
  MapPin,
  Phone,
  Ruler,
  Share2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { PropertyGallery } from './PropertyGallery';
import { PropertyMap } from './PropertyMap';
import { ContactForm } from './ContactForm';
import { useAuth } from '@/hooks/useAuth';
import { useFavorite } from '@/hooks/useFavorite';
import type { Property } from '@/lib/types';

interface PropertyDetailsProps {
  property: Property;
}

export function PropertyDetails({ property }: PropertyDetailsProps) {
  const { user } = useAuth();
  const { isFavorited, toggleFavorite } = useFavorite(property.id);
  const [showContactForm, setShowContactForm] = useState(false);

  const handleShare = async () => {
    try {
      await navigator.share({
        title: property.title,
        text: property.description,
        url: window.location.href,
      });
    } catch (error) {
      // Fallback to copying to clipboard
      navigator.clipboard.writeText(window.location.href);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid gap-8 lg:grid-cols-3">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">{property.title}</h1>
            <div className="flex items-center text-muted-foreground">
              <MapPin className="h-4 w-4 mr-1" />
              <span>{property.location}</span>
            </div>
          </div>

          <PropertyGallery images={property.images} />

          <div className="grid gap-4 sm:grid-cols-4">
            <Card className="p-4 text-center">
              <Ruler className="h-5 w-5 mx-auto mb-2" />
              <div className="text-lg font-semibold">{property.acres}</div>
              <div className="text-sm text-muted-foreground">Acres</div>
            </Card>
            {property.bedrooms > 0 && (
              <Card className="p-4 text-center">
                <Bed className="h-5 w-5 mx-auto mb-2" />
                <div className="text-lg font-semibold">{property.bedrooms}</div>
                <div className="text-sm text-muted-foreground">Bedrooms</div>
              </Card>
            )}
            {property.bathrooms > 0 && (
              <Card className="p-4 text-center">
                <Bath className="h-5 w-5 mx-auto mb-2" />
                <div className="text-lg font-semibold">{property.bathrooms}</div>
                <div className="text-sm text-muted-foreground">Bathrooms</div>
              </Card>
            )}
            <Card className="p-4 text-center">
              <Calendar className="h-5 w-5 mx-auto mb-2" />
              <div className="text-sm text-muted-foreground">
                Listed on{' '}
                {format(new Date(property.createdAt), 'MMM d, yyyy')}
              </div>
            </Card>
          </div>

          <div className="space-y-4">
            <h2 className="text-2xl font-semibold">Description</h2>
            <p className="text-muted-foreground whitespace-pre-line">
              {property.description}
            </p>
          </div>

          <PropertyMap address={property.address} />
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <Card className="p-6">
            <div className="text-3xl font-bold mb-6">
              ${property.price.toLocaleString()}
            </div>
            <div className="space-y-4">
              <Button className="w-full" onClick={() => setShowContactForm(true)}>
                <Mail className="mr-2 h-4 w-4" />
                Contact Agent
              </Button>
              {user && (
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => toggleFavorite()}
                >
                  <Heart
                    className={`mr-2 h-4 w-4 ${
                      isFavorited ? 'fill-current' : ''
                    }`}
                  />
                  {isFavorited ? 'Saved' : 'Save Property'}
                </Button>
              )}
              <Button
                variant="outline"
                className="w-full"
                onClick={handleShare}
              >
                <Share2 className="mr-2 h-4 w-4" />
                Share
              </Button>
            </div>

            <Separator className="my-6" />

            <div className="space-y-4">
              <div className="flex items-center">
                <Phone className="h-4 w-4 mr-2" />
                <span>(123) 456-7890</span>
              </div>
              <div className="flex items-center">
                <Mail className="h-4 w-4 mr-2" />
                <span>info@landfinder.com</span>
              </div>
            </div>
          </Card>

          {showContactForm && (
            <Card className="p-6">
              <ContactForm
                propertyId={property.id}
                onClose={() => setShowContactForm(false)}
              />
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}