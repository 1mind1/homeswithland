import { useState } from 'react';
import { ChevronLeft, ChevronRight, Expand } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from '@/components/ui/dialog';
import { AspectRatio } from '@/components/ui/aspect-ratio';
import type { PropertyImage } from '@/lib/types';

interface PropertyGalleryProps {
  images: PropertyImage[];
}

export function PropertyGallery({ images }: PropertyGalleryProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showFullscreen, setShowFullscreen] = useState(false);

  const primaryImage = images.find((img) => img.isPrimary)?.url;
  const sortedImages = [
    primaryImage,
    ...images.filter((img) => !img.isPrimary).map((img) => img.url),
  ].filter(Boolean) as string[];

  const navigate = (direction: 'prev' | 'next') => {
    if (direction === 'prev') {
      setCurrentIndex((prev) =>
        prev === 0 ? sortedImages.length - 1 : prev - 1
      );
    } else {
      setCurrentIndex((prev) =>
        prev === sortedImages.length - 1 ? 0 : prev + 1
      );
    }
  };

  return (
    <div className="relative group">
      <AspectRatio ratio={16 / 9}>
        <img
          src={sortedImages[currentIndex]}
          alt={`Property image ${currentIndex + 1}`}
          className="w-full h-full object-cover rounded-lg"
        />
      </AspectRatio>

      <div className="absolute inset-0 flex items-center justify-between p-4 opacity-0 group-hover:opacity-100 transition-opacity">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('prev')}
          className="bg-white/80 hover:bg-white"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <Dialog open={showFullscreen} onOpenChange={setShowFullscreen}>
          <DialogTrigger asChild>
            <Button
              variant="outline"
              size="icon"
              className="bg-white/80 hover:bg-white"
            >
              <Expand className="h-4 w-4" />
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-screen-lg">
            <div className="relative">
              <img
                src={sortedImages[currentIndex]}
                alt={`Property image ${currentIndex + 1}`}
                className="w-full h-full object-contain"
              />
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-white/80 px-4 py-2 rounded-full">
                {currentIndex + 1} / {sortedImages.length}
              </div>
            </div>
          </DialogContent>
        </Dialog>
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('next')}
          className="bg-white/80 hover:bg-white"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-white/80 px-4 py-2 rounded-full">
        {currentIndex + 1} / {sortedImages.length}
      </div>
    </div>
  );
}