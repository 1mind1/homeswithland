import { useState, useEffect, useRef } from 'react';
import { Loader } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface PropertyMapProps {
  address: string;
}

export function PropertyMap({ address }: PropertyMapProps) {
  const mapRef = useRef<HTMLIFrameElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const encodedAddress = encodeURIComponent(address);
    const mapUrl = `https://www.google.com/maps/embed/v1/place?key=YOUR_GOOGLE_MAPS_API_KEY&q=${encodedAddress}`;
    
    if (mapRef.current) {
      mapRef.current.src = mapUrl;
    } else {
      setError('Unable to load map component');
    }
  }, [address]);

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Location</h2>
      <div className="relative rounded-lg overflow-hidden">
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
            <Loader className="h-8 w-8 animate-spin" />
          </div>
        )}
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>
              {error}
            </AlertDescription>
          </Alert>
        )}
        <iframe
          ref={mapRef}
          width="100%"
          height="450"
          style={{ border: 0 }}
          allowFullScreen
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          onLoad={() => setIsLoading(false)}
        />
      </div>
    </div>
  );
}