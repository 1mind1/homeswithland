import { useState, useCallback } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { debounce } from '@/lib/utils';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export function PropertySearch() {
  const navigate = useNavigate();
  const [location, setLocation] = useState('');
  const [priceRange, setPriceRange] = useState('');
  const [acreage, setAcreage] = useState('');

  // Debounced search function
  const debouncedSearch = useCallback(
    debounce((searchParams: URLSearchParams) => {
      navigate({ to: '/properties', search: searchParams.toString() });
    }, 300),
    [navigate]
  );

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (location) params.append('location', location);
    if (priceRange) params.append('price', priceRange);
    if (acreage) params.append('acres', acreage);
    debouncedSearch(params);
  };

  return (
    <form onSubmit={handleSearch} className="rounded-lg bg-white shadow-md p-6">
      <div className="grid gap-4 md:grid-cols-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700">Location</label>
          <Input
            placeholder="Enter city or state"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700">Price Range</label>
          <Select value={priceRange} onValueChange={setPriceRange}>
            <SelectTrigger>
              <SelectValue placeholder="Select price range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="0-50000">Under $50,000</SelectItem>
              <SelectItem value="50000-100000">$50,000 - $100,000</SelectItem>
              <SelectItem value="100000-150000">$100,000 - $150,000</SelectItem>
              <SelectItem value="150000-200000">$150,000 - $200,000</SelectItem>
              <SelectItem value="200000-250000">$200,000 - $250,000</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700">Acreage</label>
          <Select value={acreage} onValueChange={setAcreage}>
            <SelectTrigger>
              <SelectValue placeholder="Select acreage" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1-2">1-2 acres</SelectItem>
              <SelectItem value="2-5">2-5 acres</SelectItem>
              <SelectItem value="5-10">5-10 acres</SelectItem>
              <SelectItem value="10-20">10-20 acres</SelectItem>
              <SelectItem value="20+">20+ acres</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-end">
          <Button type="submit" className="w-full">
            <Search className="mr-2 h-4 w-4" />
            Search Properties
          </Button>
        </div>
      </div>
    </form>
  );
}