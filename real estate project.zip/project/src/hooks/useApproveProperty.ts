import { useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'react-hot-toast';
import { supabase } from '@/lib/supabase';

export function useApproveProperty() {
  const queryClient = useQueryClient();

  const approveMutation = useMutation({
    mutationFn: async (propertyId: string) => {
      const { error } = await supabase
        .from('properties')
        .update({ status: 'approved' })
        .eq('id', propertyId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pendingProperties'] });
      toast.success('Property approved successfully');
    },
    onError: () => {
      toast.error('Failed to approve property');
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async (propertyId: string) => {
      const { error } = await supabase
        .from('properties')
        .update({ status: 'rejected' })
        .eq('id', propertyId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pendingProperties'] });
      toast.success('Property rejected');
    },
    onError: () => {
      toast.error('Failed to reject property');
    },
  });

  return {
    approveProperty: approveMutation.mutate,
    rejectProperty: rejectMutation.mutate,
  };
}