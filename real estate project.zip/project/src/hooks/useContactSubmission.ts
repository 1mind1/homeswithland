import { useMutation } from '@tanstack/react-query';
import { toast } from 'react-hot-toast';
import { supabase } from '@/lib/supabase';

interface ContactSubmission {
  name: string;
  email: string;
  message: string;
  propertyId: string;
}

export function useContactSubmission() {
  const mutation = useMutation({
    mutationFn: async (data: ContactSubmission) => {
      const { error } = await supabase.from('contact_submissions').insert([
        {
          name: data.name,
          email: data.email,
          message: data.message,
          property_id: data.propertyId,
          status: 'new',
        },
      ]);

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('Message sent successfully');
    },
    onError: () => {
      toast.error('Failed to send message');
    },
  });

  return {
    submitContact: mutation.mutate,
    isSubmitting: mutation.isPending,
  };
}