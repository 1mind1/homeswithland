import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import type { Property } from '@/lib/types';

export function useProperties() {
  return useQuery({
    queryKey: ['properties'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('properties')
        .select(`
          *,
          property_images(*)
        `)
        .eq('status', 'approved')
        .order('created_at', { ascending: false });

      if (error) throw error;

      return data.map((property) => ({
        ...property,
        images: property.property_images,
        createdAt: property.created_at,
        updatedAt: property.updated_at,
      })) as Property[];
    },
  });
}