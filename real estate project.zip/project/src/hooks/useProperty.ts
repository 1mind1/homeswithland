import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import type { Property } from '@/lib/types';

export function useProperty(propertyId: string) {
  return useQuery({
    queryKey: ['property', propertyId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('properties')
        .select(`
          *,
          property_images(*)
        `)
        .eq('id', propertyId)
        .single();

      if (error) throw error;

      return {
        ...data,
        images: data.property_images,
        createdAt: data.created_at,
        updatedAt: data.updated_at,
      } as Property;
    },
  });
}