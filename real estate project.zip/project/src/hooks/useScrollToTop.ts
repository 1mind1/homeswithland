import { useEffect } from 'react';
import { router } from '@/routeTree';

export function useScrollToTop() {
  useEffect(() => {
    const unsubscribe = router.subscribe('onNavigate', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    return () => {
      unsubscribe();
    };
  }, []);
}