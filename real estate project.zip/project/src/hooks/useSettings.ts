import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'react-hot-toast';
import { supabase } from '@/lib/supabase';

const defaultSettings = {
  siteName: 'LandFinder',
  contactEmail: 'info@landfinder.com',
  enableRegistration: true,
  requireApproval: true,
  maxPropertiesPerUser: 10,
};

export function useSettings() {
  const queryClient = useQueryClient();

  const { data: settings, isLoading } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('settings')
        .select('*')
        .single();

      if (error) {
        if (error.code === 'PGRST116') {
          // Table is empty, return defaults
          return defaultSettings;
        }
        throw error;
      }

      return data || defaultSettings;
    },
  });

  const mutation = useMutation({
    mutationFn: async (newSettings: typeof defaultSettings) => {
      const { error } = await supabase
        .from('settings')
        .upsert([{ id: 1, ...newSettings }]);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['settings'] });
      toast.success('Settings updated successfully');
    },
    onError: () => {
      toast.error('Failed to update settings');
    },
  });

  return {
    settings,
    isLoading,
    updateSettings: mutation.mutate,
  };
}