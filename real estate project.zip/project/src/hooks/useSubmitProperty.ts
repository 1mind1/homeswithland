import { useMutation } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useAuth } from './useAuth';

export function useSubmitProperty() {
  const { user } = useAuth();

  const mutation = useMutation({
    mutationFn: async (propertyData: any) => {
      const { data, error } = await supabase.from('properties').insert([
        {
          ...propertyData,
          user_id: user?.id,
          status: 'pending',
        },
      ]);

      if (error) throw error;
      return data;
    },
  });

  return {
    submitProperty: mutation.mutate,
    isSubmitting: mutation.isPending,
    error: mutation.error,
  };
}