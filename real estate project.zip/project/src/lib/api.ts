import Stripe from 'stripe';
import { supabase } from './supabase';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
});

export const PLAN_PRICES = {
  monthly: 'price_1QYkfbCdkhGjWcEpIZhWmmA3',
  annual: 'price_1QYkggCdkhGjWcEpDV4xXu2F',
  lifetime: 'price_1QYkhaCdkhGjWcEpmxpMO42F'
};

export const PLAN_AMOUNTS = {
  monthly: 579,   // $5.79
  annual: 5900,   // $59.00
  lifetime: 12900 // $129.00
} as const;

export async function createPaymentIntent(plan: string) {
  try {
    if (!plan || !PLAN_AMOUNTS[plan as keyof typeof PLAN_AMOUNTS]) {
      throw new Error('Invalid plan selected');
    }

    // Create payment intent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: PLAN_AMOUNTS[plan as keyof typeof PLAN_AMOUNTS],
      currency: 'usd',
      automatic_payment_methods: {
        enabled: true,
      },
      payment_method_types: ['card'],
      metadata: {
        plan,
        timestamp: new Date().toISOString(),
      },
      description: `${plan.charAt(0).toUpperCase() + plan.slice(1)} plan subscription`,
    });

    return { clientSecret: paymentIntent.client_secret };
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to create payment intent';
    throw new Error(message);
  }
}