import { redirect, LoaderFunctionArgs } from '@tanstack/react-router';
import type { User } from './types';
import { supabase } from './supabase';

export async function requireAuth({ context }: LoaderFunctionArgs) {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.user) {
    throw redirect({ to: '/signin' });
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', session.user.id)
    .single();

  if (!profile) {
    throw redirect({ to: '/signin' });
  }

  const user: User = {
    id: profile.id,
    email: profile.email,
    fullName: profile.full_name,
    avatarUrl: profile.avatar_url,
    role: profile.role,
  };

  return user;
}

export async function requireAdmin({ context }: LoaderFunctionArgs) {
  const user = await requireAuth({ context });
  
  if (user.role !== 'admin') {
    throw redirect({ to: '/' });
  }

  return user;
}