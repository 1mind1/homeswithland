// API configuration
const API_URL = import.meta.env.PROD ? 'https://api.homeswith.land' : '';

export const config = {
  api: {
    endpoints: {
      createCheckoutSession: '/.netlify/functions/create-checkout-session',
      webhooks: '/.netlify/functions/webhooks'
    }
  },
  stripe: {
    publishableKey: import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY,
  }
} as const;