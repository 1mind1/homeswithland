export function generateRobots() {
  return `
User-agent: *
Allow: /
Disallow: /api/
Disallow: /admin/
Disallow: /dashboard/
Disallow: /signin
Disallow: /signup

Sitemap: https://homeswith.land/sitemap.xml
  `.trim();
}