export function generatePropertySchema(property: any) {
  return {
    '@context': 'https://schema.org',
    '@type': 'RealEstateListing',
    name: property.title,
    description: property.description,
    price: property.price,
    image: property.images[0]?.url,
    address: {
      '@type': 'PostalAddress',
      addressLocality: property.location,
      addressCountry: 'US'
    },
    datePosted: property.createdAt,
    propertyType: 'SingleFamilyResidence',
    floorSize: {
      '@type': 'QuantitativeValue',
      value: property.acres,
      unitText: 'acres'
    }
  };
}

export function generateAgentSchema(agent: any) {
  return {
    '@context': 'https://schema.org',
    '@type': 'RealEstateAgent',
    name: agent.name,
    image: agent.image,
    description: agent.bio,
    telephone: agent.phone,
    email: agent.email,
    address: {
      '@type': 'PostalAddress',
      streetAddress: agent.address
    },
    areaServed: agent.serviceAreas.map((area: string) => ({
      '@type': 'State',
      name: area
    }))
  };
}

export function generateOrganizationSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Affordable Homes with Land',
    url: 'https://homeswith.land',
    logo: 'https://homeswith.land/logo.png',
    sameAs: [
      'https://youtube.com/@affordablehomeswithland',
      'https://facebook.com/affordablehomeswithland',
      'https://x.com/homeswithlandus',
      'https://instagram.com/affordablehomeswithland'
    ],
    contactPoint: {
      '@type': 'ContactPoint',
      telephone: '+1-234-567-8900',
      contactType: 'customer service',
      email: 'info@homeswith.land'
    }
  };
}