import { supabase } from './supabase';

export async function generateSitemap() {
  const baseUrl = 'https://homeswith.land';
  const date = new Date().toISOString();

  // Static routes
  const staticRoutes = [
    '',
    '/properties',
    '/agents',
    '/about',
    '/contact',
    '/blog',
    '/plans'
  ].map(route => ({
    url: `${baseUrl}${route}`,
    lastmod: date,
    changefreq: route === '' ? 'daily' : 'weekly',
    priority: route === '' ? 1.0 : 0.8
  }));

  // Dynamic routes from database
  const [properties, agents, posts] = await Promise.all([
    supabase.from('properties').select('id, updated_at').eq('status', 'approved'),
    supabase.from('agents').select('id, updated_at'),
    supabase.from('blog_posts').select('slug, updated_at').eq('published', true)
  ]);

  const propertyRoutes = (properties.data || []).map(property => ({
    url: `${baseUrl}/properties/${property.id}`,
    lastmod: property.updated_at,
    changefreq: 'weekly',
    priority: 0.9
  }));

  const agentRoutes = (agents.data || []).map(agent => ({
    url: `${baseUrl}/agents/${agent.id}`,
    lastmod: agent.updated_at,
    changefreq: 'weekly',
    priority: 0.8
  }));

  const blogRoutes = (posts.data || []).map(post => ({
    url: `${baseUrl}/blog/${post.slug}`,
    lastmod: post.updated_at,
    changefreq: 'monthly',
    priority: 0.7
  }));

  return [...staticRoutes, ...propertyRoutes, ...agentRoutes, ...blogRoutes];
}