import { loadStripe } from '@stripe/stripe-js';
import { config } from './config';

const publishableKey = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY!;
if (!publishableKey) {
  throw new Error('Missing Stripe publishable key');
}

export const stripePromise = loadStripe(publishableKey);

export const PRICE_IDS = {
  monthly: 'price_1Qb0hmCdkhGjWcEpv84Q0GsK',   // $5.79/month
  annual: 'price_1Qb0i9CdkhGjWcEp5J9oSX8t',    // $59/year
  lifetime: 'price_1Qb0iSCdkhGjWcEpFXaUncIP'   // $129 one-time
};

export async function initiateCheckout(plan: string) {
  const stripe = await stripePromise;
  if (!stripe) {
    throw new Error('Stripe failed to initialize');
  }

  const priceId = PRICE_IDS[plan.toLowerCase() as keyof typeof PRICE_IDS];
  if (!priceId) {
    throw new Error('Invalid plan selected');
  }

  const origin = window.location.origin;
  if (!origin) {
    throw new Error('Could not determine origin URL');
  }

  try {
    const response = await fetch(config.api.endpoints.createCheckoutSession, {
      method: 'POST',
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        plan: plan.toLowerCase(),
        priceId
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
    }
    
    const data = await response.json();

    if (!data.sessionId) {
      throw new Error('Invalid response: Missing session ID');
    }

    const result = await stripe.redirectToCheckout({
      sessionId: data.sessionId
    });

    if (result.error) {
      throw new Error(result.error.message || 'Failed to redirect to checkout');
    }
  } catch (error) {
    console.error('Checkout error:', error);
    if (error instanceof Error) {
      throw error;
    } else {
      throw new Error('Failed to process checkout');
    }
  }
}