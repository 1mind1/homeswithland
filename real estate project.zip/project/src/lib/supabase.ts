import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  throw new Error('Missing Supabase credentials');
}

export const supabase = createClient(supabaseUrl, supabaseKey);

export type Tables = {
  properties: {
    id: string;
    title: string;
    description: string;
    price: number;
    acres: number;
    bedrooms: number;
    bathrooms: number;
    location: string;
    address: string;
    status: 'pending' | 'approved' | 'rejected';
    created_at: string;
    updated_at: string;
    user_id: string;
    featured: boolean;
  };
  property_images: {
    id: string;
    property_id: string;
    url: string;
    is_primary: boolean;
    created_at: string;
  };
  profiles: {
    id: string;
    email: string;
    full_name: string;
    avatar_url: string;
    role: 'user' | 'admin';
    created_at: string;
  };
  favorites: {
    id: string;
    user_id: string;
    property_id: string;
    created_at: string;
  };
  blog_posts: {
    id: string;
    title: string;
    content: string;
    slug: string;
    author_id: string;
    published: boolean;
    created_at: string;
    updated_at: string;
    category: string;
  };
  contact_submissions: {
    id: string;
    name: string;
    email: string;
    message: string;
    property_id: string;
    created_at: string;
    status: 'new' | 'read' | 'replied';
  };
};