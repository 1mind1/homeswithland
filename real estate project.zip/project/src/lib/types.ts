export type Property = {
  id: string;
  title: string;
  description: string;
  price: number;
  acres: number;
  bedrooms: number;
  bathrooms: number;
  location: string;
  address: string;
  images: PropertyImage[];
  featured: boolean;
  createdAt: string;
  updatedAt: string;
};

export type PropertyImage = {
  id: string;
  propertyId: string;
  url: string;
  isPrimary: boolean;
};

export type User = {
  id: string;
  email: string;
  fullName: string;
  avatarUrl: string;
  role: 'user' | 'admin';
};

export type BlogPost = {
  id: string;
  title: string;
  content: string;
  slug: string;
  authorId: string;
  published: boolean;
  category: string;
  createdAt: string;
  updatedAt: string;
};

export type Agent = {
  id: string;
  name: string;
  company: string;
  image: string;
  location: string;
  specialties: string[];
  featured: boolean;
  listingCount: number;
  bio: string;
  phone: string;
  email: string;
  address: string;
  education: string;
  serviceAreas: string[];
};