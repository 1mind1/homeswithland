import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Image loading optimization
export const preloadImage = (src: string) => {
  const img = new Image();
  img.src = src;
};

// Debounce function for performance
export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}