import { Route as rootRoute } from './routes/_layout';
import { Route as indexRoute } from './routes/index';

export const routeTree = rootRoute.addChildren([indexRoute]);