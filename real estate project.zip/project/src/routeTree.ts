import { createRouter } from '@tanstack/react-router';
import { Route as rootRoute } from './routes/_layout';
import { Route as indexRoute } from './routes/index';
import { Route as propertiesRoute } from './routes/properties';
import { Route as propertyRoute } from './routes/properties.$propertyId';
import { Route as submitPropertyRoute } from './routes/submit-property';
import { Route as plansRoute } from './routes/plans';
import { Route as agentsIndexRoute } from './routes/agents/index';
import { Route as agentSubmitRoute } from './routes/agents/submit';
import { Route as blogRoute } from './routes/blog';
import { Route as aboutRoute } from './routes/about';
import { Route as contactRoute } from './routes/contact';
import { Route as adminRoute } from './routes/admin';
import { Route as signInRoute } from './routes/signin';
import { Route as signUpRoute } from './routes/signup';
import { Route as signUpPlanRoute } from './routes/signup.$plan/layout';
import { Route as signUpPaymentRoute } from './routes/signup.$plan/payment';
import { Route as signUpAccountRoute } from './routes/signup.$plan/account';

declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router;
  }
}

const routeTree = rootRoute.addChildren([
  indexRoute,
  propertiesRoute,
  propertyRoute,
  plansRoute,
  agentsIndexRoute,
  agentSubmitRoute,
  submitPropertyRoute,
  blogRoute,
  aboutRoute,
  contactRoute,
  adminRoute,
  signInRoute,
  signUpRoute.addChildren([
    signUpPlanRoute.addChildren([
      signUpPaymentRoute,
      signUpAccountRoute,
    ]),
  ]),
]);

export const router = createRouter({ routeTree });

declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router;
  }
}