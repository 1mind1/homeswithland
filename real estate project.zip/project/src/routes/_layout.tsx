import { Outlet, createRootRoute } from '@tanstack/react-router';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { useScrollToTop } from '@/hooks/useScrollToTop';
import { Toaster } from '@/components/ui/toaster';

export const Route = createRootRoute({
  component: Layout,
});

function Layout() {
  useScrollToTop();

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <Outlet />
      </main>
      <Footer />
      <Toaster />
    </div>
  );
}