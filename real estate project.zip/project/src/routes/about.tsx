import { createRoute } from '@tanstack/react-router';
import { Route as rootRoute } from './_layout';
import { AboutHero } from '@/components/about/AboutHero';
import { AboutMission } from '@/components/about/AboutMission';
import { AboutTeam } from '@/components/about/AboutTeam';

export const Route = createRoute({
  getParentRoute: () => rootRoute,
  path: '/about',
  component: AboutPage,
});

function AboutPage() {
  return (
    <div className="space-y-16">
      <AboutHero />
      <AboutMission />
      <AboutTeam />
    </div>
  );
}