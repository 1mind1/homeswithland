import { createRoute, LoaderFunctionArgs } from '@tanstack/react-router';
import { Route as rootRoute } from './_layout';
import { AdminDashboard } from '@/components/admin/AdminDashboard';
import { requireAdmin } from '@/lib/auth';

export const Route = createRoute({
  getParentRoute: () => rootRoute,
  path: '/admin',
  loader: async ({ context }: LoaderFunctionArgs) => {
    return requireAdmin({ context });
  },
  component: AdminPage,
});

function AdminPage() {
  return <AdminDashboard />;
}