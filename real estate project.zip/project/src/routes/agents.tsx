import { createRoute } from '@tanstack/react-router';
import { Route as rootRoute } from './_layout';
import { AgentDirectory } from '@/components/agents/AgentDirectory';

export const Route = createRoute({
  getParentRoute: () => rootRoute,
  path: '/agents',
  component: AgentsPage,
});

function AgentsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <AgentDirectory />
      </div>
    </div>
  );
}