import { createRoute } from '@tanstack/react-router';
import { Route as rootRoute } from '../_layout';
import { AgentDirectory } from '@/components/agents/AgentDirectory';
import { Helmet } from 'react-helmet';

export const Route = createRoute({
  getParentRoute: () => rootRoute,
  path: '/agents',
  component: AgentsPage,
});

function AgentsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Helmet>
        <title>Find a Real Estate Agent | Specialized in Properties with Land</title>
        <meta name="description" content="Connect with experienced real estate agents specializing in properties with land. Browse our directory of professionals across all 50 states." />
        <meta name="keywords" content="real estate agents, land specialists, property agents, acreage experts" />
        <link rel="canonical" href="https://homeswith.land/agents" />
        <meta property="og:title" content="Find a Real Estate Agent | Specialized in Properties with Land" />
        <meta property="og:description" content="Connect with experienced real estate agents specializing in properties with land." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://homeswith.land/agents" />
      </Helmet>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <AgentDirectory />
      </div>
    </div>
  );
}