import { createRoute } from '@tanstack/react-router';
import { Route as rootRoute } from '../_layout';
import { AgentSubmissionForm } from '@/components/agents/AgentSubmissionForm';

export const Route = createRoute({
  getParentRoute: () => rootRoute,
  path: '/agents/submit',
  component: AgentSubmissionPage,
});

function AgentSubmissionPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold">Join Our Agent Directory</h1>
            <p className="mt-2 text-muted-foreground">
              Connect with buyers looking for properties with land and acreage
            </p>
          </div>
          <AgentSubmissionForm />
        </div>
      </div>
    </div>
  );
}