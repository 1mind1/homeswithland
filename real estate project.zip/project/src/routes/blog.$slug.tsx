import { createRoute } from '@tanstack/react-router';
import { Route as rootRoute } from './_layout';

export const Route = createRoute({
  getParentRoute: () => rootRoute,
  path: '/blog/$slug',
  component: BlogPostPage,
});

function BlogPostPage() {
  const { slug } = Route.useParams();
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1>Blog Post: {slug}</h1>
    </div>
  );
}