import { createRoute } from '@tanstack/react-router';
import { Route as rootRoute } from './_layout';
import { BlogList } from '@/components/blog/BlogList';

export const Route = createRoute({
  getParentRoute: () => rootRoute,
  path: '/blog',
  component: BlogPage,
});

function BlogPage() {
  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      <div className="max-w-2xl mx-auto text-center">
        <h1 className="text-4xl font-bold tracking-tight">Latest Updates</h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Tips, insights, and stories about affordable country living and homesteading.
        </p>
      </div>
      <BlogList />
    </div>
  );
}