import { createRoute } from '@tanstack/react-router';
import { Route as rootRoute } from './_layout';
import { HeroSection } from '@/components/home/HeroSection';
import { FeaturesSection } from '@/components/home/FeaturesSection';
import { AgentDirectorySection } from '@/components/home/AgentDirectorySection';
import { ListingCTA } from '@/components/home/ListingCTA';
import { YouTubeSection } from '@/components/home/YouTubeSection';
import { NewsletterSection } from '@/components/home/NewsletterSection';
import { RecentBlogPosts } from '@/components/blog/RecentBlogPosts';
import { FeaturedProperties } from '@/components/properties/FeaturedProperties';

export const Route = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',
  component: HomePage,
});

function HomePage() {
  return (
    <div className="space-y-16">
      <HeroSection />
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <FeaturesSection />
        <div className="mt-16">
          <FeaturedProperties />
        </div>
        <div className="mt-16">
          <AgentDirectorySection />
        </div>
        <div className="mt-16">
          <RecentBlogPosts />
        </div>
        <div className="mt-16">
          <ListingCTA />
        </div>
        <div className="mt-16">
          <YouTubeSection />
        </div>
        <div className="mt-16">
          <NewsletterSection />
        </div>
      </div>
    </div>
  );
}