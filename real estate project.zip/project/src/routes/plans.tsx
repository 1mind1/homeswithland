import { useState, useEffect } from 'react';
import { createRoute } from '@tanstack/react-router';
import { Route as rootRoute } from './_layout';
import { PlanToggle } from '@/components/plans/PlanToggle';
import { PricingPlans } from '@/components/plans/PricingPlans';
import { SubscriptionPlans } from '@/components/plans/SubscriptionPlans';

const planTypes = ['list', 'subscribe'] as const;

export const Route = createRoute({
  getParentRoute: () => rootRoute,
  path: '/plans',
  validateSearch: (search: Record<string, string>) => ({
    tab: search.tab as typeof planTypes[number] || 'list'
  }),
  component: PlansPage,
});

function PlansPage() {
  const { tab } = Route.useSearch();
  const [planType, setPlanType] = useState<typeof planTypes[number]>(tab);

  useEffect(() => {
    setPlanType(tab);
  }, [tab]);

  return (
    <div className="py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl sm:text-center">
          <div className="flex flex-col items-center gap-6">
            <PlanToggle selected={planType} onToggle={setPlanType} />
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
              {planType === 'list' ? 'List Your Property' : 'Join Our Community'}
            </h2>
          </div>
          <p className="mt-6 text-lg leading-8 text-muted-foreground">
            {planType === 'list'
              ? 'Choose the perfect plan to showcase your property to thousands of potential buyers.'
              : 'Get unlimited access to our curated selection of affordable properties with land.'}
          </p>
        </div>
        {planType === 'list' ? <PricingPlans /> : <SubscriptionPlans />}
      </div>
    </div>
  );
}