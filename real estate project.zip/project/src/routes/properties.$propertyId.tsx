import { createRoute } from '@tanstack/react-router';
import { Route as rootRoute } from './_layout';
import { PropertyDetails } from '@/components/properties/PropertyDetails';
import { useProperty } from '@/hooks/useProperty';

export const Route = createRoute({
  getParentRoute: () => rootRoute,
  path: '/properties/$propertyId',
  component: PropertyPage,
});

function PropertyPage() {
  const { propertyId } = Route.useParams();
  const { property, isLoading, error } = useProperty(propertyId);

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error || !property) {
    return (
      <div className="text-center py-12">
        <p className="text-red-500">Property not found or error loading details.</p>
      </div>
    );
  }

  return <PropertyDetails property={property} />;
}