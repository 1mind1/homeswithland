import { createRoute, redirect, LoaderFunctionArgs } from '@tanstack/react-router';
import { Route as rootRoute } from './_layout';
import { PropertySearch } from '@/components/properties/PropertySearch';
import { PropertyGrid } from '@/components/properties/PropertyGrid';
import { useProperties } from '@/hooks/useProperties';
import { supabase } from '@/lib/supabase';

export const Route = createRoute({
  getParentRoute: () => rootRoute,
  path: '/properties',
  loader: async ({ context }: LoaderFunctionArgs) => {
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session?.user) {
      throw redirect({ 
        to: '/signin',
        search: {
          redirect: '/properties'
        }
      });
    }

    // Check if user has an active subscription
    const { data: subscription } = await supabase
      .from('subscriptions')
      .select('status')
      .eq('user_id', session.user.id)
      .single();

    if (!subscription || subscription.status !== 'active') {
      throw redirect({ 
        to: '/plans',
        search: {
          tab: 'subscribe'
        }
      });
    }

    return null;
  },
  component: PropertiesPage,
});

function PropertiesPage() {
  const { properties, isLoading, error } = useProperties();

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-500">Error loading properties. Please try again later.</p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <PropertySearch />
      <PropertyGrid properties={properties} isLoading={isLoading} />
    </div>
  );
}