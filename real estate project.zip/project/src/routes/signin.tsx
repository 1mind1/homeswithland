import { createRoute, redirect, LoaderFunctionArgs } from '@tanstack/react-router';
import { Route as rootRoute } from './_layout';
import { SignInForm } from '@/components/auth/SignInForm';
import { supabase } from '@/lib/supabase';

export const Route = createRoute({
  getParentRoute: () => rootRoute,
  path: '/signin',
  validateSearch: (search: Record<string, string>) => ({
    redirect: search.redirect,
  }),
  loader: async ({ context }: LoaderFunctionArgs) => {
    const { data: { session } } = await supabase.auth.getSession();
    if (session?.user) {
      throw redirect({ to: '/' });
    }
    return null;
  },
  component: SignInPage,
});

function SignInPage() {
  const { redirect } = Route.useSearch();

  return (
    <div className="min-h-[80vh] flex items-center justify-center">
      <SignInForm redirectTo={redirect} />
    </div>
  );
}