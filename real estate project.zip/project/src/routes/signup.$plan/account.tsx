import { useState, useEffect } from 'react';
import { createRoute } from '@tanstack/react-router';
import { Route as rootRoute } from './layout';
import { SignUpForm } from '@/components/auth/SignUpForm';
import { Confetti } from '@/components/shared/Confetti';

export const Route = createRoute({
  getParentRoute: () => rootRoute,
  path: '/account',
  component: AccountPage,
});

function AccountPage() {
  const { plan } = Route.useParams();
  const [showConfetti, setShowConfetti] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setShowConfetti(false), 5000);
    return () => clearTimeout(timer);
  }, []);
  
  return (
    <div className="min-h-[80vh] flex items-center justify-center">
      {showConfetti && <Confetti />}
      <div className="w-full max-w-md">
        <SignUpForm plan={plan} />
      </div>
    </div>
  );
}