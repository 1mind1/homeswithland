import { Outlet, createRoute } from '@tanstack/react-router';
import { Route as rootRoute } from '../_layout';

export const Route = createRoute({
  getParentRoute: () => rootRoute,
  path: '/signup/$plan',
  component: SignUpLayout,
});

function SignUpLayout() {
  return <Outlet />;
}