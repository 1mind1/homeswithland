import { useEffect, useState } from 'react';
import { createRoute } from '@tanstack/react-router';
import { Route as rootRoute } from './layout';
import { initiateCheckout } from '@/lib/stripe';
import { toast } from 'react-hot-toast';

export const Route = createRoute({
  getParentRoute: () => rootRoute,
  path: '/payment',
  component: PaymentPage,
});

function PaymentPage() {
  const { plan } = Route.useParams();
  const [isRedirecting, setIsRedirecting] = useState(true);
  const [error, setError] = useState<string>();

  useEffect(() => {
    const startCheckout = async () => {
      try {
        if (!plan || !['monthly', 'annual', 'lifetime'].includes(plan.toLowerCase())) {
          throw new Error('Invalid plan');
        }

        setIsRedirecting(true);
        await initiateCheckout(plan);
      } catch (error) {
        console.error('Checkout error:', error instanceof Error ? error.message : error);
        const message = error instanceof Error ? error.message : 'Failed to start checkout';
        setError(message);
        toast.error(message);
        setIsRedirecting(false);
      }
    };

    startCheckout();
  }, [plan]);

  if (!isRedirecting) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 mb-4">Failed to redirect to checkout</p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-primary text-white rounded hover:bg-primary/90"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
        <p className="mt-4 text-sm text-muted-foreground">Redirecting to checkout...</p>
      </div>
    </div>
  );
}