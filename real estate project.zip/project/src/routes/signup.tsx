import { createRoute, redirect, LoaderFunctionArgs } from '@tanstack/react-router';
import { Route as rootRoute } from './_layout';
import { supabase } from '@/lib/supabase';

export const Route = createRoute({
  getParentRoute: () => rootRoute,
  path: '/signup',
  loader: async ({ context }: LoaderFunctionArgs) => {
    const { data: { session } } = await supabase.auth.getSession();
    if (session?.user) {
      throw redirect({ to: '/' });
    }
    throw redirect({ to: '/plans' });
  },
});