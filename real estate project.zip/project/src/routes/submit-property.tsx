import { createRoute, LoaderFunctionArgs } from '@tanstack/react-router';
import { Route as rootRoute } from './_layout';
import { PropertyForm } from '@/components/properties/PropertyForm';
import { requireAuth } from '@/lib/auth';

export const Route = createRoute({
  getParentRoute: () => rootRoute,
  path: '/submit-property',
  loader: async ({ context }: LoaderFunctionArgs) => {
    return requireAuth({ context });
  },
  component: SubmitPropertyPage,
});

function SubmitPropertyPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-2xl font-bold mb-6">Submit a Property</h1>
      <PropertyForm />
    </div>
  );
}