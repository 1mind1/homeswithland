/*
  # Stripe Integration Setup

  1. New Tables
    - `subscriptions`
      - Stores user subscription information
      - Links to Stripe customer and subscription IDs
    - `prices`
      - Stores product price information synced from Stripe
    - `customers`
      - Stores Stripe customer information
    
  2. Security
    - Enable RLS on all tables
    - Add policies for secure access
*/

-- Customers table
CREATE TABLE customers (
  id uuid REFERENCES auth.users(id) PRIMARY KEY,
  stripe_customer_id text UNIQUE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Prices table
CREATE TABLE prices (
  id text PRIMARY KEY,
  product_id text,
  active boolean,
  description text,
  unit_amount bigint,
  currency text,
  type text CHECK (type IN ('one_time', 'recurring')),
  interval text CHECK (interval IN ('day', 'week', 'month', 'year')),
  created_at timestamptz DEFAULT now()
);

-- Subscriptions table
CREATE TABLE subscriptions (
  id text PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id),
  status text CHECK (status IN ('trialing', 'active', 'canceled', 'incomplete', 'incomplete_expired', 'past_due', 'unpaid')),
  metadata jsonb,
  price_id text REFERENCES prices(id),
  quantity integer,
  cancel_at_period_end boolean,
  created_at timestamptz DEFAULT now(),
  current_period_start timestamptz,
  current_period_end timestamptz,
  ended_at timestamptz,
  cancel_at timestamptz,
  canceled_at timestamptz,
  trial_start timestamptz,
  trial_end timestamptz
);

-- Enable RLS
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE prices ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can view their own customer data" ON customers
  FOR SELECT TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Anyone can view active prices" ON prices
  FOR SELECT TO anon, authenticated
  USING (active = true);

CREATE POLICY "Users can view their own subscriptions" ON subscriptions
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);