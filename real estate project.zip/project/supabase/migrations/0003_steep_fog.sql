/*
  # Fix property_images relationship

  1. Changes
    - Drop and recreate property_images table with correct foreign key relationship
    - Re-enable RLS and policies
*/

-- Drop existing table and policies
DROP TABLE IF EXISTS property_images;

-- Recreate property_images table with correct relationship
CREATE TABLE property_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id uuid REFERENCES properties(id) ON DELETE CASCADE,
  url text NOT NULL,
  is_primary boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE property_images ENABLE ROW LEVEL SECURITY;

-- Recreate policies
CREATE POLICY "Anyone can view property images"
  ON property_images
  FOR SELECT
  USING (true);

CREATE POLICY "Users can insert property images"
  ON property_images
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM properties
      WHERE id = property_images.property_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update their own property images"
  ON property_images
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM properties
      WHERE id = property_images.property_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete their own property images"
  ON property_images
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM properties
      WHERE id = property_images.property_id
      AND user_id = auth.uid()
    )
  );